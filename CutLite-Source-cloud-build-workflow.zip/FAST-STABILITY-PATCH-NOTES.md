# CutLite fast/stability source patch

This patch is based on the supplied CutLite source and the startup-diagnostics patch. It is a source change, not a compiled or device-tested APK.

## Included
- Shows a visible startup screen before GeckoView initializes.
- Catches synchronous startup failures and writes `cutlite-startup.log` in the app-private files directory, with Logcat tag `CutLiteStartup`.
- Defers Android runtime permission prompts until GeckoView actually requests a permission, rather than showing several permission prompts during launch.
- Handles the permission result asynchronously and rejects overlapping permission requests.

## Performance finding
The current HTML export uses `canvas.captureStream()` plus `MediaRecorder` and advances the timeline against wall-clock time. This means export is fundamentally real-time (or slower on a device that cannot prepare frames quickly). Changing GeckoView to WebView alone will not make exports faster. A true faster-than-real-time export requires a separate native rendering/export pipeline. Because this editor draws custom canvas effects, transitions, masks, and text, that pipeline must preserve those visuals; blindly routing all projects through Media3 would lose unsupported effects.

## Safe engine strategy
- Keep one UI/browser engine per build; do not run GeckoView and WebView together.
- Keep the existing FFmpeg bridge isolated to native format conversion.
- Add a native fast-export path only for projects whose clips/effects are supported, with the existing canvas exporter as compatibility fallback.
- Do not launch Media3 and FFmpeg concurrently on the same export.

## Not claimed
- No APK was built.
- No runtime crash was confirmed fixed on a physical phone.
- No export-speed improvement is claimed yet.

# Android permission and manifest consistency fix

- Microphone/camera requests now trigger Android's runtime permission dialog only when the editor requests the corresponding capture source.
- The GeckoView media callback is retained until the permission result, then granted with the requested source(s) or rejected cleanly.
- Concurrent media permission prompts are rejected rather than overwriting the pending callback.
- Added the CAMERA permission declaration alongside RECORD_AUDIO.
- Removed manifest package/version/uses-sdk duplicates; Gradle's namespace, applicationId, SDK levels and version are the single source of truth.
- Kept the top-level compatibility copies of MainActivity and AndroidManifest synchronized with the Gradle module.

Validation performed: source structure check, inline JavaScript syntax check, and AndroidManifest XML parse. A Gradle APK build and real-device permission test have NOT been performed in this environment.

# Download Blob Memory Cleanup

- Added a shared `downloadBlob()` helper for generated MP3, video, and Premiere XML downloads.
- Generated object URLs are revoked after a 60-second grace period so Android/WebView download handling has time to adopt the blob.
- Imported source-media object URLs are intentionally untouched; they remain valid while clips/history may reference them.
- Kept the packaged Android `assets/www/index.html` synchronized with the root editor HTML.

Validation: source replacement assertions and HTML/packaged-asset byte comparison. This is not an Android APK build or device test.

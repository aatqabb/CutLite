# Android runtime reuse and diagnostics hardening

- Retain a single process-wide GeckoRuntime and reuse it when Android recreates MainActivity. This avoids attempting to create a second Gecko engine in the same process during configuration/lifecycle changes.
- Create the runtime with the application context so it does not retain a short-lived Activity.
- Bound the private startup log to approximately 512 KiB and rotate the previous log, preventing unbounded growth on low-storage devices.
- Build diagnostic share text with StringBuilder and handle devices with no compatible share target.
- Give the local asset server a stable ServerSocket reference, a named thread, a bounded request timeout, and explicit shutdown handling.

Validation: offline source preflight only. Gradle compilation and physical-device testing remain required; this update is not an APK release.

# Mobile preview optimization — 2026-11-12

## Changes
- Chroma-key preview frame processing is throttled based on `navigator.deviceMemory` and `navigator.hardwareConcurrency`: 10 fps on lower-resource devices, about 15 fps on mid-range devices, and about 30 fps on higher-resource devices.
- Kept the chroma-key working canvas at up to 512 px so the shared canvas used by the export compositor does not silently lose source detail on lower-resource devices.
- Replaced per-pixel square-root distance checks with squared-distance comparisons for the fully transparent and fully opaque regions; square root is now only needed in the narrow feather band.
- Requested a 2D context with `willReadFrequently` for the pixel-read/write chroma-key path.
- Static images are processed once rather than scheduling an endless animation-frame loop.
- Synced the editor HTML into the Android packaged asset path.

## Validation
- Extracted the inline JavaScript and passed `node --check`.
- This is a source-level optimization only. No Android APK build or physical-device performance test was possible in this environment.

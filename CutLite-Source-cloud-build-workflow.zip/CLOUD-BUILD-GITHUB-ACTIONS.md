# CutLite cloud APK build (no local Android SDK required)

This project includes `.github/workflows/android-debug-apk.yml` so GitHub Actions can build the debug APK on a hosted Ubuntu runner.

## Run it from an Android phone
1. Create a private GitHub repository (or use an existing private repository).
2. Upload the contents of this source ZIP to the repository root. Keep `.github/workflows/android-debug-apk.yml` and the `android-app/` folder in place. If GitHub's mobile web uploader hides dot-folders, create the workflow file in the GitHub web editor at `.github/workflows/android-debug-apk.yml` and paste the workflow contents from this ZIP.
3. Open the repository's **Actions** tab.
4. Select **Build CutLite Android APK**, tap **Run workflow**, and start it on `main` or `master`.
5. Wait for the run to finish. A green check means Gradle produced the debug APK. A red cross means the build log contains the exact dependency or compilation error to fix next.
6. Open the completed run, scroll to **Artifacts**, and download **CutLite-debug-apk**. Extract the ZIP and install `app-debug.apk` on the test phone.

## Important
- This is a debug-signed test APK, not a Play Store release.
- It will not update an existing installation signed with a different key; uninstall the old app first only if you are comfortable losing its app-private data. Back up projects first.
- A successful cloud build is not proof of device compatibility. Test launch, project persistence, media import, preview, and export on the Vivo phone.
- GitHub account access and a repository are required. Never put signing keys, passwords, or tokens in source files.

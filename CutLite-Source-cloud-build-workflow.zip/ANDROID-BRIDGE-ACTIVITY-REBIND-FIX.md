# CutLite WebExtension Activity Rebind Fix

## Issue addressed

The GeckoRuntime and its built-in WebExtension are process-scoped, while `MainActivity` can be recreated. The extension message delegate was installed only when GeckoRuntime was first created and captured the first Activity instance. After a rotation or Activity recreation, export notifications could therefore be delivered to a destroyed Activity and its stale `pendingExports` map.

## Change

- Added a process-local `activeActivity` reference.
- Set it when a new MainActivity instance starts.
- The long-lived WebExtension delegate resolves the current Activity at message-delivery time and ignores messages if there is no live Activity.
- Clear the reference when that Activity is destroyed.
- Synchronized the legacy Java mirrors with the Gradle module source.
- Added preflight checks for delegate routing, reference cleanup, and mirror parity.

## Validation

`python android-app/scripts/preflight.py` — 44/44 checks passed.

This is source-level validation only. Gradle compilation and physical-device testing are still required.

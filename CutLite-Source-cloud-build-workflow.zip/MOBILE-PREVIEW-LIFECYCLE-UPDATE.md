# Mobile preview lifecycle update — 2026-11-12

## Changes
- Chroma-key video preview now schedules its next frame only while the editor is playing. A paused video is processed once, instead of keeping a perpetual animation-frame callback alive.
- Static-image chroma-key preview remains one-shot, but changing the key colour now schedules a fresh frame so the preview updates immediately.
- Switching away from a keyed clip cancels the pending animation-frame callback, clears the active clip reference, and resets the frame-throttle clock. This prevents stale work from continuing after the keyed clip is no longer visible.
- Switching between keyed clips resets the throttle clock so the new clip does not inherit the previous clip's delay.
- Synced the editor HTML into the Android packaged asset path.

## Validation
- Extracted the inline JavaScript and passed `node --check`.
- Confirmed the editor HTML and packaged Android asset are byte-identical.
- ZIP integrity checked after packaging.
- Source-level change only; no Android APK build or physical-device performance test was available.

# Local server startup failure guard

CutLite requires its stable `http://127.0.0.1:18765/` origin for project autosave.
If binding the local asset server fails, the app now stops on its diagnostic startup
screen instead of silently loading the same editor from `resource://` (an opaque
origin that cannot access the existing localhost `localStorage`). The message makes
clear that projects were not deleted and suggests closing another CutLite instance
before retrying.

This is a source-level startup safety fix. It has not yet been compiled into an APK
or tested on a physical Android device.

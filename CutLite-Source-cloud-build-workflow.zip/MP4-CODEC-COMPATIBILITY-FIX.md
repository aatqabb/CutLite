# MP4 codec compatibility fix

The Android export implementation previously requested FFmpeg `libx264`. The selected maintained FFmpeg LGPL artifact does not promise that GPL-only encoder; the project publishes separate GPL variants. A missing encoder would make MP4 conversion fail on devices even when the FFmpeg native library loaded successfully.

The app now uses FFmpeg built-in `mpeg4` (MPEG-4 Part 2) for MP4 container output. UI labels and native save notes were updated so the codec is not misrepresented as H.264. This avoids silently changing the dependency to a GPL artifact. MP4 playback compatibility must still be checked on target Android devices. If H.264 is a strict requirement, integrate Android MediaCodec/Media3 or deliberately select a GPL build after reviewing redistribution obligations.

Validation: run `python3 android-app/scripts/preflight.py`. This is static validation only; Gradle compilation and device playback tests remain outstanding.

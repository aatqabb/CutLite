# Cut·Lite — Mobile Video Editor (full source)

A free, lightweight mobile video editor. The editor itself is a single
self-contained HTML file; the Android app wraps it in Mozilla GeckoView
(the Firefox engine, bundled inside the APK) so it does not depend on
the phone's system WebView. Native export (real MP4/H.264 and MP3) is
done with FFmpegKit.

## What is in this package

| File | What it is |
|---|---|
| `mobile-video-editor.html` | **The editor app itself (build22).** One 434 KB HTML file: multi-track timeline, transitions, text animations, filters, keyframes, voiceover, export (WebM/MP4/MP3, fps, bitrate). This is the file to edit for editor features. |
| `android-app/AndroidManifest.xml` | App manifest. Package `com.muse.videoeditor`, versionCode 2, versionName 1.0, minSdk 26 (Android 8.0), targetSdk 34. `android:extractNativeLibs="true"` (required — see "Known issues"). |
| `android-app/MainActivity.java` | The FFmpeg build's activity: starts an embedded localhost HTTP server, loads the HTML in GeckoView, installs the CutLite Native Bridge WebExtension, transcodes exports to real MP4/MP3 with FFmpegKit. |
| `android-app/MainActivity-base.java` | The base build's activity (GeckoView only, no FFmpeg — WebM export only). |
| `android-app/assets/www/index.html` | The copy of the editor HTML that ships inside the APK. Identical to `mobile-video-editor.html` (same md5). Edit the top-level file, then copy it here before building. |
| `android-app/web_extensions/cutlite-bridge/` | Built-in WebExtension ("CutLite Native Bridge"): reports each export (format/fps/bitrate) to native code and shims MediaRecorder so MP4/MP3 requests record as WebM for later transcode. |
| `android-app/res/drawable/ic_launcher.png` | Current app icon (a grey camera, 180x180). **Needs replacing — see "Open work".** |
| `android-app/res/values/strings.xml` | App name string. |
| `android-app/scripts/build_engine.sh` | Builds the FFmpeg APK (manual aapt2/d8/zipalign/apksigner pipeline; Gradle is unusable in the original VM, so this script is the build). |
| `android-app/scripts/build_engine_base.sh` | Builds the base APK (same, no FFmpeg). |
| `android-app/scripts/make_base_mainactivity.py` | Derives the base MainActivity from the FFmpeg one. |
| `android-app/scripts/resolve_deps.py` | Resolves the `deps/` libraries into the dex build. |
| `android-app/deps/` | Pre-resolved AndroidX/Kotlin/Media3 libraries (AAR/JAR) used by the build. |
| `android-app/*.gradle`, `gradle.properties` | Gradle project files (kept for reference; the scripts above are the working build). |

## How the pieces fit together

1. The user opens the app → `MainActivity` starts a tiny HTTP server on
   `http://127.0.0.1:<port>/` serving `assets/www/index.html` (localhost
   gives the page a real origin, so localStorage auto-save works).
2. The page runs in GeckoView (bundled Firefox engine). No System WebView
   is used anywhere.
3. Export: the page records with MediaRecorder. For MP4/MP3 the bridge
   extension makes the page record WebM, reports the chosen format/fps/
   bitrate to native code, and `MainActivity` transcodes the staged WebM
   to real H.264 MP4 (`libx264` + AAC + faststart) or MP3 (`libmp3lame`)
   with FFmpegKit, then copies the result to Downloads.

## Building an APK (what you need)

- Android SDK build-tools (aapt2, d8, zipalign, apksigner) + a JDK.
- **GeckoView 159** AARs (NOT included — 172 MB): `org.mozilla.geckoview:geckoview-omni-arm64-v8a:159.0.20261102144711` and `...:geckoview-omni-armeabi-v7a:159.0.20261102144711` from Mozilla Maven. They provide `libxul.so`, `omni.ja` and the GeckoView classes. The build scripts expect them under a `gecko-2026-11-11/` folder next to the project.
- **ffmpeg-kit 8.1.9** AAR (NOT included — 30 MB): `dev.ffmpegkit-maintained:ffmpeg-kit-full:8.1.9` from Maven Central (the maintained fork; the original arthenica artifact is gone). FFmpeg native libs are arm64-v8a only.
- Set `sdk.dir` in a `local.properties` file to your Android SDK path.
- Run `scripts/build_engine.sh` (FFmpeg APK) or `scripts/build_engine_base.sh`
  (base APK). The scripts use `zipalign -f -p 4` (page-aligns `.so` files).

## Signing — important

The installed APKs are signed with the **Android debug key**
(CN=Android Debug, SHA-256
`72d396a3d884b839ad495bbbf198b7c2d7852d8754bb633be39c38343e748a61`).
**The keystore is NOT included in this package.** A new APK signed with a
different key will NOT install over the current app — Android will refuse
it ("App not installed") and the old app must be uninstalled first (which
loses its saved data). To keep updates installing in place, the new APK
must be signed with the same key. (The original builder can re-sign a
new APK with the same key on request.)

## Open work (please fix / improve)

1. **The engine APK installs but does not open.** On the user's phone
   (Vivo V50, Android 14) the FIXED APK installs fine, but tapping the
   app icon does nothing — the app never opens. Static checks all pass
   (manifest parses, signature verifies, native libs present for
   arm64-v8a, `omni.ja` present at `assets/omni.ja`, WebExtension assets
   present). Suspects: GeckoRuntime initialisation failing silently,
   first-launch native-library load taking too long (black screen), or a
   crash in `onCreate` before anything is drawn. Please add a visible
   startup splash + an on-screen error message and a startup log file so
   the failure can be diagnosed, and make the launch robust.
2. **The app icon is bad.** `res/drawable/ic_launcher.png` is a plain
   grey camera on black. Replace it with a premium logo for "Cut·Lite"
   (video editor): deep charcoal background with a soft gold mark,
   matching the app's design (charcoal #121417, gold #C9A86A). Provide it
   in all densities (mipmap-mdpi/hdpi/xhdpi/xxhdpi/xxxhdpi) and update
   the manifest icon reference.
3. General: keep improving the editor (see the HTML). The app's design
   language is premium, muted colours only, tiny thin chips/icons, no
   big bold announcements.

## Known history (so you do not repeat it)

- The install used to fail with "APK can't be installed" because the
  manifest had `android:extractNativeLibs="false"` while no `.so` file
  was page-aligned. Fixed by setting it to `"true"` and using
  `zipalign -f -p 4`. Do not set it back to `false` unless every `.so`
  is page-aligned (offset % 4096 == 0).
- Rotation was removed from the editor entirely (build22) at the user's
  request — do not reintroduce it.
- MP3 export in the browser build is disabled (no browser reports an mp3
  mimeType); real MP3 only exists through the FFmpeg native transcode.
- Exported audio contains transition sounds only; clip audio/music are
  not routed into exports yet.
- The user will NOT publish on Google Play; the APK is distributed
  directly (sideloaded). No AAB, no Play account needed.

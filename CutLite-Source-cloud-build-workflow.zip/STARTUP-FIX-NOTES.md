# CutLite startup-fix patch (static source patch)

## Changes applied
- Added a visible startup screen before GeckoView initialization.
- Wrapped the Android startup sequence in a `Throwable` handler so Java exceptions and native-link errors can be displayed instead of silently terminating the activity.
- Added `cutlite-startup.log` in the app's private files directory and Android Logcat tag `CutLiteStartup`.
- Logged local server, GeckoRuntime, and GeckoSession initialization milestones.
- Removed eager startup requests for microphone and media-library permissions. The system file picker handles media selection; microphone permission should be requested only when voiceover is actually started.

## Important limitations
This is a source-code patch, NOT a rebuilt or tested APK. The supplied source archive does not contain the GeckoView 159 AARs, FFmpegKit 8.1.9 AAR, Android SDK/build-tools, or the signing keystore required by the build scripts. The build scripts also reference a developer-specific absolute workspace path and source paths such as `engine-app/app/src/main/...` that do not match this archive's `android-app/` layout. Those build-environment issues still need to be resolved before a new APK can be produced.

## What the next build should verify
1. Confirm GeckoView 159 AARs and FFmpegKit 8.1.9 AAR are present for the expected ABIs.
2. Rebuild and install the APK on the Vivo V60 (Android 16).
3. If startup still fails, read `files/cutlite-startup.log` via a diagnostic export or use Android bug report. The visible error screen should show the exception class and message.
4. Verify FFmpeg native loading and MP4/MP3 export separately after the editor opens.

Do not treat this patch as proof that the crash is fixed: it makes the failure visible and records diagnostics so the exact failing stage can be identified.


### JavaScript syntax validation

The Android build entry point also runs `android-app/scripts/validate_javascript.py`.
When Node.js is available, it syntax-checks both packaged WebExtension scripts and
inline JavaScript in every HTML copy. If Node.js is unavailable, this optional check
prints `SKIP` and the Android build continues; it does not make Node.js a runtime
requirement for the app.

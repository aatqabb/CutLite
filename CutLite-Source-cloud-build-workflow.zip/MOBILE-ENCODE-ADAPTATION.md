# Mobile encode adaptation (source update)

This update replaces the fixed four-thread x264 budget with a conservative device-aware budget based on Android's reported memory class and available CPU cores:

- low memory class (<=192 MB) or <=4 cores: 1 encode thread
- memory class <=320 MB or <=6 cores: 2 encode threads
- larger devices: up to 3 threads, always leaving at least one reported core free
- MP3 encoding uses one thread

The existing `veryfast` H.264 preset and `yuv420p` output remain in place. This does not change the user's selected output resolution or frame rate. It is a source-level tuning change; actual speed, heat, and compatibility still require Gradle build and device testing.

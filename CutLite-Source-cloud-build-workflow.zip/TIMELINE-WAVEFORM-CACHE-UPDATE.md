# Timeline waveform cache update

- Added a deterministic, bounded 160-entry cache for generated audio waveform markup.
- Repeated timeline renders reuse the same waveform HTML instead of recalculating 28 bars per audio clip on every rebuild.
- Cache is bounded to avoid unbounded memory growth; evicts the oldest inserted entry.
- Kept waveform appearance, clip timing, audio playback and export behavior unchanged.
- Synced the exact updated editor HTML into the Android app packaged asset.

Validation: source parity and JavaScript syntax checks are run on this package. This is a source optimization, not a measured device benchmark or built APK.

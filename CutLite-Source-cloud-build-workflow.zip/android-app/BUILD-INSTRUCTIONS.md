# Portable Android build layout

This archive now contains a conventional Gradle Android application module at `app/`.

## Build

1. Install Android Studio (or Android SDK + JDK 17) on a build computer.
2. Open this `android-app` directory as a Gradle project.
3. Allow Gradle to resolve Maven dependencies.
4. Build `app > Tasks > build > assembleDebug`.
5. APK: `app/build/outputs/apk/debug/app-debug.apk`.

Command line from this directory: `gradle :app:assembleDebug`.

## Important compatibility notes

- The app uses GeckoView 159, so minimum Android is API 26 (Android 8.0). Android 12, 13, 14, 15 and 16 are within the declared range.
- FFmpegKit is resolved from the maintained-fork Maven coordinate. Verify its provenance, license and ABI coverage before public distribution.
- Debug signing is for test installs only. It will not update an installed APK signed with a different key; uninstalling the old app may be required.
- This change makes the Gradle project layout portable; it does not prove a successful build or device compatibility. Build and device testing are still required.

## Mobile export performance and safety update

The Android MP4 transcode uses FFmpeg's built-in `mpeg4` encoder (MPEG-4 Part 2),
with bounded encoding threads. This avoids silently requiring the GPL-only x264
encoder from the maintained FFmpeg package. The resulting file is an MP4 container,
but its video codec is MPEG-4 Part 2 rather than H.264; verify target-player
compatibility before distribution. It is still a transcode, not a
real-time guarantee: export duration depends on source resolution, effects,
codec support, thermals, and available memory. Download filenames are sanitized
before being used as cache/Downloads paths, and empty/unavailable Downloads
outputs are reported rather than silently treated as saved.

## Offline source preflight

Before opening Android Studio, run:

```bash
python3 scripts/preflight.py
```

This checks the project structure and several common integration mistakes. It is
not a substitute for `:app:assembleDebug`, dependency resolution, or device QA.

## Download pipeline hardening

The native download bridge stages each incoming export in a unique temporary
file, preventing simultaneous same-name exports from clobbering one another.
On Android 10+, MediaStore items remain pending until the copy succeeds; failed
partial items are removed. Staging and output streams are closed safely.

## One-command build and diagnostics

From the `android-app` directory run:

```bash
bash scripts/build_android.sh
```

The script runs source preflight first, verifies Java and Android SDK presence,
then invokes `:app:assembleDebug`. It stops with a specific diagnostic if a
required build tool is missing. It does not use the old hard-coded manual
pipeline in `scripts/build_engine.sh`.

The project currently does not bundle a Gradle wrapper. Install Gradle 8.9 or
newer (compatible with Android Gradle Plugin 8.7.3), or open the project in
Android Studio and let it configure Gradle. Use JDK 17 for the most predictable
Android build environment.

## Source synchronization safeguard

The preflight now compares the canonical `mobile-video-editor.html` against
both Android asset copies. This caught and corrected a stale legacy asset
copy during this update. A successful 20/20 preflight means source layout and
selected integration invariants pass; it does not mean Java compilation or
APK packaging has passed.


## Permission and device-availability scope

The manifest retains the media-library read permissions required by the current
editor import workflow. Camera and microphone hardware are declared optional;
Android runtime permissions are requested when the relevant capability is used.
The file picker remains available for user-selected files. Do not remove these
permissions without first changing and testing the editor's import workflow.

## Stable local origin and saved-project persistence

The embedded asset server binds to `127.0.0.1:18765` instead of selecting a random
port. This is important because browser `localStorage` is scoped to the full origin,
including the port. A random port on each launch or Activity recreation can make
previously saved projects appear to vanish even though the data remains on disk.
The fixed loopback-only port preserves the same origin across launches. If that
port is already occupied, startup logs the bind failure and uses the existing
fallback page; the port must not be changed casually because doing so changes the
localStorage origin and can hide existing projects.

#!/usr/bin/env python3
"""Offline structural and JavaScript syntax checks for CutLite source."""
from html.parser import HTMLParser
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[2]
APP = ROOT / 'android-app'
MODULE = APP / 'app'

class Scripts(HTMLParser):
    def __init__(self):
        super().__init__(); self.in_script = False; self.current = []; self.items = []
    def handle_starttag(self, tag, attrs):
        if tag.lower() == 'script' and not dict(attrs).get('src'):
            self.in_script = True; self.current = []
    def handle_data(self, data):
        if self.in_script: self.current.append(data)
    def handle_endtag(self, tag):
        if tag.lower() == 'script' and self.in_script:
            self.items.append(''.join(self.current)); self.in_script = False

errors = []
def require(condition, message):
    if not condition: errors.append(message)

html = ROOT / 'mobile-video-editor.html'
packaged_html = MODULE / 'src/main/assets/www/index.html'
manifest = MODULE / 'src/main/AndroidManifest.xml'
java = MODULE / 'src/main/java/com/muse/videoeditor/MainActivity.java'
for path in (html, packaged_html, manifest, java, APP / 'settings.gradle', MODULE / 'build.gradle', APP / 'MainActivity.java', APP / 'AndroidManifest.xml'):
    require(path.is_file(), f'Missing required file: {path.relative_to(ROOT)}')
if html.exists() and packaged_html.exists():
    require(html.read_bytes() == packaged_html.read_bytes(), 'Packaged editor HTML is out of sync with source HTML')
if manifest.exists():
    m = manifest.read_text(errors='replace')
    require('android.permission.RECORD_AUDIO' in m and 'android.permission.CAMERA' in m, 'Media capture permissions missing from manifest')
    require('<uses-sdk' not in m and 'android:versionCode=' not in m, 'SDK/version must be controlled by Gradle, not duplicated in manifest')
if java.exists():
    j = java.read_text(errors='replace')
    require((APP / 'MainActivity.java').read_bytes() == java.read_bytes(), 'Top-level MainActivity mirror is out of sync')
    require('MEDIA_PERM_REQ' in j and 'pendingMediaPermissionCallback' in j, 'Runtime microphone/camera permission request flow missing')
    require((APP / 'AndroidManifest.xml').read_bytes() == manifest.read_bytes(), 'Top-level manifest mirror is out of sync')
    require('encodePermit.acquire()' in j and 'encodePermit.release()' in j,
            'Native export serialization guard missing')
    require('GeckoRuntime.create' in j, 'GeckoView runtime initialization missing')

if html.exists():
    parser = Scripts(); parser.feed(html.read_text(errors='replace'))
    require(bool(parser.items), 'No inline JavaScript blocks found in editor HTML')
    node = subprocess.run(['node', '--version'], capture_output=True, text=True)
    if node.returncode == 0:
        with tempfile.TemporaryDirectory(prefix='cutlite-js-') as td:
            for i, source in enumerate(parser.items):
                f = Path(td) / f'inline-{i}.js'; f.write_text(source)
                result = subprocess.run(['node', '--check', str(f)], capture_output=True, text=True)
                if result.returncode:
                    errors.append(f'Inline JS block {i} syntax error: {(result.stderr or result.stdout).strip()}')
            bridge = APP / 'web_extensions/cutlite-bridge/content.js'
            bg = APP / 'web_extensions/cutlite-bridge/background.js'
            for f in (bridge, bg):
                if f.exists():
                    result = subprocess.run(['node', '--check', str(f)], capture_output=True, text=True)
                    if result.returncode: errors.append(f'{f.name} syntax error: {(result.stderr or result.stdout).strip()}')
    else:
        errors.append('Node.js not installed; JavaScript syntax checks skipped')

if errors:
    print('CUTLITE SOURCE CHECK: FAILED')
    for e in errors: print(' -', e)
    sys.exit(1)
print('CUTLITE SOURCE CHECK: PASSED')
print(' - Android module structure present')
print(' - packaged editor HTML matches source')
print(' - native export queue guard present')
print(' - runtime media permission flow and manifest mirrors present')
print(' - inline editor and bridge JavaScript syntax valid')
print('Note: this is not an Android APK build or device test.')

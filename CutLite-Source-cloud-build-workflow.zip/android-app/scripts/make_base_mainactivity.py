#!/usr/bin/env python3
"""Derive the BASE (GeckoView-only, no FFmpeg) MainActivity.java from the
FFmpeg MainActivity.java by stripping the native-export bridge code.
Run: python3 make_base_mainactivity.py
Reads:  engine-app/app/src/main/java/com/muse/videoeditor/MainActivity.java
Writes: engine-app/app-base/src/main/java/com/muse/videoeditor/MainActivity.java
Fails loudly if any expected marker is missing (so a silent partial strip
can never produce a broken source file).
"""
import os, sys

BASE = os.path.expanduser("~/workspace/video_editor_installers")
SRC = os.path.join(BASE, "engine-app/app/src/main/java/com/muse/videoeditor/MainActivity.java")
DST_DIR = os.path.join(BASE, "engine-app/app-base/src/main/java/com/muse/videoeditor")
DST = os.path.join(DST_DIR, "MainActivity.java")

with open(SRC, "r", encoding="utf-8") as f:
    src = f.read()

def must_find(sub, label):
    if sub not in src:
        print("FATAL: marker not found: %s" % label)
        sys.exit(1)

# 1. ffmpeg imports
for imp in (
    "import com.arthenica.ffmpegkit.FFmpegKit;\n",
    "import com.arthenica.ffmpegkit.FFmpegSession;\n",
    "import com.arthenica.ffmpegkit.ReturnCode;\n",
):
    must_find(imp, "import " + imp.strip())
    src = src.replace(imp, "")

# 2. bridge fields (+ their comment)
fields = """    // CutLite Native Bridge: the WebExtension content script reports each
    // export (filename + the format/fps/bitrate chips the user picked) just
    // before the download fires. Keyed by download filename.
    private final Map<String, JSONObject> pendingExports = new ConcurrentHashMap<>();
    private WebExtension bridgeExtension;
"""
must_find(fields, "bridge fields")
src = src.replace(fields, "")

# 3. installNativeBridge call in onCreate
call = "        installNativeBridge(runtime);\n"
must_find(call, "installNativeBridge call")
src = src.replace(call, "")

# 4. whole bridge section: from the section header to (not incl.) the
#    embedded-localhost-server header.
start = "    // ---- CutLite Native Bridge (WebExtension -> native FFmpeg export) ----"
end = "    // ---- embedded localhost server: serves assets/www/index.html ----"
i = src.find(start); j = src.find(end)
if i < 0 or j < 0 or j <= i:
    print("FATAL: bridge section markers not found")
    sys.exit(1)
src = src[:i] + src[j:]

# 5. saveDownload header comment: replace FFmpeg wording with base wording.
old_comment = """    // ---- downloads: Gecko hands the file bytes via WebResponse.body ----
    //
    // The bytes are staged in the app cache first (FFmpegKit needs a real
    // file path). If the export asked for MP4 or MP3, the staged file is
    // really WebM data (the page's MediaRecorder shim records MP4/MP3
    // requests as WebM, since Gecko cannot record those containers) — it
    // is transcoded to MP4 / MP3 with FFmpegKit before being
    // copied to Downloads. WebM exports and other files go straight through.
"""
new_comment = """    // ---- downloads: Gecko hands the file bytes via WebResponse.body ----
    //
    // Base build (no native export engine): the bytes are staged in the
    // app cache first, then copied to Downloads exactly as the browser
    // recorded them (WebM). No transcode happens in this variant.
"""
must_find(old_comment, "saveDownload header comment")
src = src.replace(old_comment, new_comment)

# 6. saveDownload: replace the transcode decision with a direct copy.
old_decision = """            // Decide whether this export needs a native transcode.
            JSONObject opts = pendingExports.remove(filename);
            String want = wantsTranscode(filename, opts);
            if (want == null) {
                // No transcode: copy the staged file to Downloads as-is.
                copyToDownloads(staged, filename, mt, null);
                return;
            }
            // Transcode in the background; the final file lands in Downloads.
            transcodeExport(staged, filename, want, opts);
"""
new_decision = """            // Base build: no native transcode — copy to Downloads as-is.
            copyToDownloads(staged, filename, mt, null);
"""
must_find(old_decision, "transcode decision in saveDownload")
src = src.replace(old_decision, new_decision)

# 7a. remove methods wantsTranscode .. transcodeExport (up to copyToDownloads).
m1_start = '    // Returns "mp4" or "mp3" when the staged file must be transcoded to that'
m1_end = "    private void copyToDownloads(File src, String filename, String mime, String note) {"
i = src.find(m1_start); j = src.find(m1_end)
if i < 0 or j < 0 or j <= i:
    print("FATAL: methods block A markers not found")
    sys.exit(1)
src = src[:i] + src[j:]

# 7b. remove the export-option-parsing section (parseQuality .. audioBitrate).
m2_start = "    // ---- export option parsing (same numbers as the app's expBitrates()) ----"
m2_end = "    private String filenameFrom(WebResponse r) {"
i = src.find(m2_start); j = src.find(m2_end)
if i < 0 or j < 0 or j <= i:
    print("FATAL: methods block B markers not found")
    sys.exit(1)
src = src[:i] + src[j:]

# 8. javadoc note: mark this as the base variant.
old_javadoc = """/**
 * Mobile Video Editor — GeckoView (Firefox engine) build.
"""
new_javadoc = """/**
 * Mobile Video Editor — GeckoView (Firefox engine) build.
 * BASE variant: no native FFmpeg export engine — exports are saved
 * exactly as the browser recorded them (WebM). Derived from the FFmpeg
 * MainActivity by stripping the CutLite Native Bridge / transcode code.
"""
must_find(old_javadoc, "class javadoc")
src = src.replace(old_javadoc, new_javadoc)

# Safety: no ffmpeg/bridge CODE leftovers may remain. (The word "FFmpeg"
# in comments/javadoc is fine — it documents that this variant has none.)
for bad in ("arthenica", "FFmpegKit", "FFmpegSession", "ReturnCode",
            "pendingExports", "bridgeExtension",
            "installNativeBridge", "handleBridgeMessage", "transcodeExport",
            "wantsTranscode", "isWebM", "parseQuality", "parseFps", "videoBitrate",
            "audioBitrate", "stagedFileFor"):
    if bad.lower() in src.lower():
        print("FATAL: leftover reference to %s" % bad)
        sys.exit(1)

os.makedirs(DST_DIR, exist_ok=True)
with open(DST, "w", encoding="utf-8") as f:
    f.write(src)
print("WROTE %s (%d lines)" % (DST, src.count("\n") + 1))

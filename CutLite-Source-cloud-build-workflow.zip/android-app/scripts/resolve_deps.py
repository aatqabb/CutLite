#!/usr/bin/env python3
"""Resolve the GeckoView 159 Maven dependency graph (compile+runtime, incl.
optional) and download every artifact (AAR preferred, else JAR).

Why this exists: Gradle cannot run in this VM — its daemon talks over Java
loopback sockets, and this runtime intercepts Java sockets (a Java client
connecting to a local Java/Python server receives "muse: ..." instead of the
real bytes; Gradle fails with "Unexpected type tag 109" = 'm'). The manual
aapt2/d8 pipeline is the only viable build route, so dependencies must be
resolved by hand. This script is that resolver.

Repos: Mozilla Maven (geckoview), Google Maven (androidx, media3, gms),
Maven Central (everything else, incl. kotlin, snakeyaml, guava).
"""
import os, re, sys, urllib.request, xml.etree.ElementTree as ET

OUT = os.path.expanduser("~/workspace/video_editor_installers/engine-app/deps")
os.makedirs(OUT, exist_ok=True)

GOOGLE = "https://dl.google.com/dl/android/maven2"
CENTRAL = "https://repo.maven.apache.org/maven2"
MOZILLA = "https://maven.mozilla.org/maven2"
NS = {"m": "http://maven.apache.org/POM/4.0.0"}

def repos_for(group):
    if group.startswith("org.mozilla.geckoview"):
        return [MOZILLA]
    if group.startswith(("androidx.", "com.google.android.gms", "com.google.guava")):
        return [GOOGLE, CENTRAL]
    return [CENTRAL, GOOGLE]

def http_get(url, dest=None):
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=60) as r:
        data = r.read()
    if dest:
        with open(dest, "wb") as f:
            f.write(data)
    return data

def pom_url(group, art, ver, repo):
    return "%s/%s/%s/%s/%s-%s.pom" % (repo, group.replace(".", "/"), art, ver, art, ver)

def fetch_pom(group, art, ver):
    for repo in repos_for(group):
        try:
            data = http_get(pom_url(group, art, ver, repo))
            return ET.fromstring(data)
        except Exception:
            continue
    raise RuntimeError("pom not found: %s:%s:%s" % (group, art, ver))

def text(el, tag):
    e = el.find("m:%s" % tag, NS)
    return e.text.strip() if e is not None and e.text else None

def collect_props(root, depth=0):
    """properties from this pom + its parents (depth<=3)."""
    props = {}
    for p in root.findall("m:properties/m:*", NS):
        if p.text:
            props[p.tag.split("}")[-1]] = p.text.strip()
    if depth < 3:
        parent = root.find("m:parent", NS)
        if parent is not None:
            pg, pa, pv = (text(parent, "groupId"), text(parent, "artifactId"),
                          text(parent, "version"))
            if pg and pa and pv:
                try:
                    props.update(collect_props(fetch_pom(pg, pa, pv), depth + 1))
                except Exception as e:
                    print("  (parent pom %s:%s:%s unavailable: %s)" % (pg, pa, pv, e))
    return props

VAR = re.compile(r"\$\{([^}]+)\}")

def ver_key(v):
    """Numeric-aware version key: 1.11.0 > 1.9.1 (string compare gets this wrong)."""
    parts = []
    for tok in re.split(r"[.\-]", v):
        if tok.isdigit():
            parts.append((0, int(tok), ""))
        else:
            parts.append((1, 0, tok))
    return tuple(parts)

def norm_version(v):
    """Strip Maven version ranges: '[2.2.0]' -> '2.2.0', '[1.0,2.0)' -> '1.0'."""
    if v is None:
        return None
    v = v.strip()
    if v.startswith("[") or v.startswith("("):
        inner = v[1:].split(",")[0].split("]")[0].split(")")[0].strip()
        return inner
    return v
def resolve(val, props, group, art, ver):
    if val is None:
        return None
    for _ in range(5):
        m = VAR.search(val)
        if not m:
            break
        key = m.group(1)
        rep = props.get(key)
        if rep is None:
            rep = {"project.version": ver, "project.groupId": group,
                   "project.artifactId": art}.get(key, "")
        val = val[:m.start()] + rep + val[m.end():]
    return val

def parse_deps(root, props, group, art, ver):
    """(group, artifact, version, packaging, scope) for compile+runtime deps."""
    # dependencyManagement versions
    mgmt = {}
    for dm in root.findall("m:dependencyManagement/m:dependencies/m:dependency", NS):
        g, a, v = text(dm, "groupId"), text(dm, "artifactId"), text(dm, "version")
        if g and a and v:
            mgmt[(g, a)] = resolve(v, props, group, art, ver)
    out = []
    for d in root.findall("m:dependencies/m:dependency", NS):
        g, a = text(d, "groupId"), text(d, "artifactId")
        v = resolve(text(d, "version"), props, group, art, ver) or mgmt.get((g, a))
        scope = text(d, "scope") or "compile"
        typ = text(d, "type") or "jar"
        if not g or not a or not v:
            continue
        if scope in ("test", "provided", "system", "import"):
            continue
        out.append((g, a, v, typ, scope))
    return out

resolved = {}   # (group, art) -> (ver, typ)
queue = []
seen_pom = set()

def enqueue(g, a, v, typ):
    key = (g, a)
    v = norm_version(v)
    if not v:
        return
    if key in resolved:
        # keep the newest version (numeric compare)
        if ver_key(v) > ver_key(resolved[key][0]):
            resolved[key] = (v, typ)
            queue.append((g, a, v, typ))
        return
    resolved[key] = (v, typ)
    queue.append((g, a, v, typ))

# seed: GeckoView 159 omni arm64-v8a pom (already on disk) + armeabi-v7a
# (identical dependency lists). Use the downloaded pom.
import glob
seed_poms = glob.glob(os.path.expanduser(
    "~/workspace/video_editor_installers/gecko-2026-11-11/*.pom"))
assert seed_poms, "seed pom missing"
root = ET.parse(seed_poms[0]).getroot()
props = collect_props(root)
for (g, a, v, typ, scope) in parse_deps(root, props, "org.mozilla.geckoview",
                                       "geckoview-omni-arm64-v8a", "159.0.20261102144711"):
    enqueue(g, a, v, typ)

while queue:
    g, a, v, typ = queue.pop(0)
    if (g, a, v) in seen_pom:
        continue
    seen_pom.add((g, a, v))
    try:
        r = fetch_pom(g, a, v)
    except Exception as e:
        print("WARN: no pom for %s:%s:%s (%s)" % (g, a, v, e))
        continue
    p2 = collect_props(r)
    p2.update(props)
    for (g2, a2, v2, t2, s2) in parse_deps(r, p2, g, a, v):
        enqueue(g2, a2, v2, t2)

print("Resolved %d artifacts:" % len(resolved))
for (g, a), (v, typ) in sorted(resolved.items()):
    print("  %s:%s:%s [%s]" % (g, a, v, typ))

# download each artifact: try .aar then .jar
dl = []
for (g, a), (v, typ) in sorted(resolved.items()):
    base = "%s/%s/%s/%s/%s-%s" % (None, None, None, None, None, None)  # placeholder
    got = None
    for repo in repos_for(g):
        for ext in (["aar", "jar"] if typ == "aar" else ["jar", "aar"]):
            url = "%s/%s/%s/%s/%s-%s.%s" % (repo, g.replace(".", "/"), a, v, a, v, ext)
            dest = os.path.join(OUT, "%s-%s.%s" % (a, v, ext))
            if os.path.exists(dest) and os.path.getsize(dest) > 0:
                got = dest
                break
            try:
                http_get(url, dest)
                if os.path.getsize(dest) > 1000:
                    got = dest
                    break
                os.remove(dest)
            except Exception:
                if os.path.exists(dest):
                    os.remove(dest)
        if got:
            break
    if got:
        dl.append((g, a, v, got))
        print("OK  %s:%s -> %s (%d bytes)" % (g, a, os.path.basename(got),
                                              os.path.getsize(got)))
    else:
        print("FAIL %s:%s:%s" % (g, a, v))

with open(os.path.join(OUT, "resolved.txt"), "w") as f:
    for (g, a, v, path) in dl:
        f.write("%s:%s:%s\t%s\n" % (g, a, v, path))
print("Downloaded %d/%d artifacts." % (len(dl), len(resolved)))

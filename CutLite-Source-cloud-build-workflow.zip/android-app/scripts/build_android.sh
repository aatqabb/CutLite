#!/usr/bin/env bash
# Reproducible Gradle entry point for CutLite. This script never silently
# falls back to the legacy machine-specific aapt2 pipeline.
set -Eeuo pipefail
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$HERE"

fail() { printf 'BUILD BLOCKED: %s\n' "$*" >&2; exit 2; }

command -v java >/dev/null 2>&1 || fail 'Java is missing. Install JDK 17.'
command -v python3 >/dev/null 2>&1 || fail 'Python 3 is required for source preflight.'
python3 scripts/preflight.py
python3 scripts/validate_javascript.py

JAVA_VERSION="$(java -version 2>&1 | head -n 1)"
if ! printf '%s' "$JAVA_VERSION" | grep -Eq 'version "(17|21)(\.|")'; then
  fail "Unsupported Java runtime: ${JAVA_VERSION}. Use JDK 17 (recommended) or a compatible JDK 21."
fi

if [[ -n "${ANDROID_HOME:-}" ]]; then SDK="$ANDROID_HOME"; elif [[ -n "${ANDROID_SDK_ROOT:-}" ]]; then SDK="$ANDROID_SDK_ROOT"; else SDK=""; fi
[[ -n "$SDK" && -d "$SDK/platforms" ]] || fail 'Android SDK not found. Set ANDROID_HOME or ANDROID_SDK_ROOT.'

if [[ -x ./gradlew ]]; then GRADLE=(./gradlew); elif command -v gradle >/dev/null 2>&1; then GRADLE=(gradle); else fail 'Gradle not found. Install Gradle 8.9+ or add a Gradle wrapper.'; fi

printf '\nUsing Java: %s\nSDK: %s\nGradle: %s\n' "$JAVA_VERSION" "$SDK" "${GRADLE[*]}"
"${GRADLE[@]}" --no-daemon --stacktrace :app:assembleDebug
APK='app/build/outputs/apk/debug/app-debug.apk'
[[ -s "$APK" ]] || fail 'Gradle completed but expected APK is missing.'
if command -v sha256sum >/dev/null 2>&1; then sha256sum "$APK"; fi
printf '\nBUILD SUCCESS: %s/%s\n' "$HERE" "$APK"

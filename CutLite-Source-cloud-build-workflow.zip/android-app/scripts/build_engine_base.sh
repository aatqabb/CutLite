#!/bin/bash
# Engine APK build (BASE variant: GeckoView only, no ffmpeg-kit, no bridge)
# — MANUAL aapt2/d8 pipeline (Gradle cannot run in this VM:
# its daemon talks over Java loopback sockets, and this runtime intercepts
# Java sockets — a Java client gets "muse: ..." instead of real bytes, so
# Gradle fails with "Unexpected type tag 109" = 'm'. Proven 2026-11-11.
# The manual pipeline uses only file I/O (aapt2/d8/zipalign/apksigner).
set -e
BASE=~/workspace/video_editor_installers
ENG=$BASE/engine-app
SDK=$BASE/android-sdk
BT=$SDK/build-tools/34.0.0
D8=$BASE/build-tools-35/android-15/d8   # d8 8.6.2: build-tools 34's d8 8.2.2 NPEs on nest-mate classes (androidx.core FrameMetricsAggregator); 8.6 handles them (auto multi-dex)
JDK=$BASE/jdk/jdk-17.0.21+9/bin
export PATH=$JDK:$PATH
export JAVA_HOME=$BASE/jdk/jdk-17.0.21+9
# /tmp is a 512MB tmpfs that fills up; point all JVM temp files at disk instead.
mkdir -p $BASE/.javatmp
export JAVA_TOOL_OPTIONS="-Djava.io.tmpdir=$BASE/.javatmp"

BUILD=$ENG/build
rm -rf $BUILD
mkdir -p $BUILD/classes $BUILD/dex $BUILD/assets/www $BUILD/lib/arm64-v8a $BUILD/lib/armeabi-v7a $BUILD/res-my $BUILD/res-gv $BUILD/javac-out

echo "== 1. stage classes (dedup, first-wins) =="
python3 - "$ENG/deps" "$BASE/gecko-2026-11-11" "$BUILD/classes" <<'EOF'
import os, sys, zipfile, hashlib
deps_dir, gecko_dir, out = sys.argv[1], sys.argv[2], sys.argv[3]
seen = {}
dups = []
# Exclude classes that reference android.webkit.WebView (LinkifyCompat calls
# WebView.findAddress; it is an unneeded androidx.core text utility — GeckoView
# and the app never use it). MimeTypeMap references are fine (MIME utility,
# not the WebView engine) and live in GeckoView/FileProvider, so they stay.
EXCLUDE_PREFIXES = ('androidx/core/text/util/LinkifyCompat',)
def add_jar(path, tag):
    try:
        z = zipfile.ZipFile(path)
    except Exception as e:
        print("  SKIP bad jar %s: %s" % (path, e)); return
    for n in z.namelist():
        if not n.endswith('.class'):
            continue
        if n.startswith('META-INF/'):
            continue  # module-info.class etc. — d8 NPEs on these
        if n.startswith(EXCLUDE_PREFIXES):
            continue  # android.webkit.WebView reference — excluded
        dest = os.path.join(out, n)
        data = z.read(n)
        if n in seen:
            if hashlib.md5(data).hexdigest() != seen[n]:
                dups.append((n, tag, seen[n][:8]))
            continue
        seen[n] = hashlib.md5(data).hexdigest()
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with open(dest, 'wb') as f:
            f.write(data)
# 1. GeckoView classes first (canonical) — AARs hold classes in classes.jar
import tempfile
_gv = os.path.join(gecko_dir, 'geckoview-omni-arm64-v8a-159.0.20261102144711.aar')
_z = zipfile.ZipFile(_gv)
with tempfile.NamedTemporaryFile(suffix='.jar', delete=False) as tf:
    tf.write(_z.read('classes.jar')); tf.close()
    add_jar(tf.name, 'geckoview')
    os.unlink(tf.name)
# 1b. (base build: no ffmpeg-kit classes)
# 2. direct GeckoView deps (from its pom) next, then the rest, alphabetical
import glob
direct = ['kotlin-stdlib-2.4.20.jar','annotation-1.11.0.jar','annotation-experimental-1.6.0.aar',
 'collection-1.6.0.jar','core-1.19.1.aar','lifecycle-common-2.11.0.jar','lifecycle-process-2.11.0.aar',
 'play-services-fido-21.3.1.aar','snakeyaml-2.2.jar','media3-common-1.11.1.aar',
 'media3-datasource-1.11.1.aar','media3-decoder-1.11.1.aar','media3-exoplayer-1.11.1.aar',
 'media3-exoplayer-hls-1.11.1.aar']
def jar_of(p):
    if p.endswith('.aar'):
        z = zipfile.ZipFile(p)
        return ('classes.jar', z)
    return (None, None)
for name in direct:
    p = os.path.join(deps_dir, name)
    if name.endswith('.aar'):
        z = zipfile.ZipFile(p)
        import tempfile
        with tempfile.NamedTemporaryFile(suffix='.jar', delete=False) as tf:
            tf.write(z.read('classes.jar')); tf.close()
            add_jar(tf.name, name)
            os.unlink(tf.name)
    else:
        add_jar(p, name)
# 3. everything else (skip the empty listenablefuture stub — Guava provides it)
for p in sorted(glob.glob(os.path.join(deps_dir, '*.aar')) + glob.glob(os.path.join(deps_dir, '*.jar'))):
    if os.path.basename(p) in direct or 'listenablefuture' in p:
        continue
    if p.endswith('.aar'):
        z = zipfile.ZipFile(p)
        if 'classes.jar' not in z.namelist():
            continue
        import tempfile
        with tempfile.NamedTemporaryFile(suffix='.jar', delete=False) as tf:
            tf.write(z.read('classes.jar')); tf.close()
            add_jar(tf.name, os.path.basename(p))
            os.unlink(tf.name)
    else:
        add_jar(p, os.path.basename(p))
print("staged classes: %d unique" % len(seen))
print("duplicate class files skipped: %d" % len(dups))
for d in dups[:20]:
    print("  DUP-diff:", d)
EOF

echo "== 2. javac MainActivity =="
javac -encoding UTF-8 -cp "$SDK/platforms/android-34/android.jar:$BUILD/classes" \
  -d $BUILD/javac-out \
  $ENG/app-base/src/main/java/com/muse/videoeditor/MainActivity.java
echo "javac OK"; find $BUILD/javac-out -name "*.class"

echo "== 3. d8 =="
# d8 (8.2.2) takes .jar/.class files, NOT directories; --multi-dex flag was
# removed in this version — it auto-splits into classes2.dex etc. if >64K methods.
(cd $BUILD/classes && jar cf $BUILD/all-classes.jar .)
(cd $BUILD/javac-out && jar uf $BUILD/all-classes.jar .)
$D8 --min-api 26 --output $BUILD/dex $BUILD/all-classes.jar
echo "d8 OK"; ls -la $BUILD/dex/

echo "== 4. stage assets + native libs =="
cp $ENG/app/src/main/assets/www/index.html $BUILD/assets/www/index.html
unzip -o -q $BASE/gecko-2026-11-11/geckoview-omni-arm64-v8a-159.0.20261102144711.aar assets/omni.ja -d $BUILD/gv-extract
cp $BUILD/gv-extract/assets/omni.ja $BUILD/assets/omni.ja
unzip -o -q $BASE/gecko-2026-11-11/geckoview-omni-arm64-v8a-159.0.20261102144711.aar "jni/arm64-v8a/*" -d $BUILD/gv-extract
unzip -o -q $BASE/gecko-2026-11-11/geckoview-omni-armeabi-v7a-159.0.20261102144711.aar "jni/armeabi-v7a/*" -d $BUILD/gv-extract
cp $BUILD/gv-extract/jni/arm64-v8a/*.so $BUILD/lib/arm64-v8a/
cp $BUILD/gv-extract/jni/armeabi-v7a/*.so $BUILD/lib/armeabi-v7a/
# (base build: no ffmpeg-kit libs, no bridge assets — exports stay WebM)
ls $BUILD/lib/arm64-v8a/ | wc -l; ls $BUILD/lib/armeabi-v7a/ | wc -l
md5sum $BUILD/assets/www/index.html $BUILD/assets/omni.ja

echo "== 5. aapt2 compile res =="
cp -r $ENG/app/src/main/res/* $BUILD/res-my/
mkdir -p $BUILD/res-gv/drawable
unzip -o -q $BASE/gecko-2026-11-11/geckoview-omni-arm64-v8a-159.0.20261102144711.aar "res/drawable/ic_generic_file.xml" -d $BUILD/gv-extract
cp $BUILD/gv-extract/res/drawable/ic_generic_file.xml $BUILD/res-gv/drawable/
$BT/aapt2 compile --dir $BUILD/res-my -o $BUILD/res-my.zip
$BT/aapt2 compile --dir $BUILD/res-gv -o $BUILD/res-gv.zip
echo "aapt2 compile OK"

echo "== 6. aapt2 link =="
$BT/aapt2 link -o $BUILD/app-unsigned.apk \
  -I $SDK/platforms/android-34/android.jar \
  --manifest $ENG/app/src/main/AndroidManifest.xml \
  --auto-add-overlay \
  -R $BUILD/res-my.zip -R $BUILD/res-gv.zip \
  --extra-packages org.mozilla.geckoview \
  --no-compress-regex 'ja$' \
  -A $BUILD/assets
echo "aapt2 link OK"

echo "== 7. add dex + native libs =="
cd $BUILD
zip -j app-unsigned.apk dex/classes*.dex
zip -0 app-unsigned.apk lib/arm64-v8a/*.so lib/armeabi-v7a/*.so
cd $ENG
echo "assemble OK"

echo "== 8. zipalign + sign =="
$BT/zipalign -f -p 4 $BUILD/app-unsigned.apk $BUILD/app-aligned.apk
$BT/apksigner sign --v1-signing-enabled=false \
  --ks $BASE/apk-src/debug.keystore --ks-pass pass:android --key-pass pass:android \
  --out $BASE/Mobile-Video-Editor-Engine-2026-11-11.apk $BUILD/app-aligned.apk
echo "sign OK"

echo "== 9. verify =="
unzip -t $BASE/Mobile-Video-Editor-Engine-2026-11-11.apk | tail -2
$BT/aapt2 dump badging $BASE/Mobile-Video-Editor-Engine-2026-11-11.apk | head -8
$BT/apksigner verify --print-certs $BASE/Mobile-Video-Editor-Engine-2026-11-11.apk
$BT/zipalign -c -v 4 $BASE/Mobile-Video-Editor-Engine-2026-11-11.apk
unzip -p $BASE/Mobile-Video-Editor-Engine-2026-11-11.apk assets/www/index.html | md5sum
ls -la $BASE/Mobile-Video-Editor-Engine-2026-11-11.apk
md5sum $BASE/Mobile-Video-Editor-Engine-2026-11-11.apk
echo "BUILD DONE"

#!/usr/bin/env python3
"""Offline preflight checks for the CutLite Android project.

This does not replace Gradle compilation or testing on a physical device.
"""
from pathlib import Path
import re
import sys
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'app'
checks = []

def check(label, condition, detail=''):
    checks.append((label, bool(condition), detail))

manifest = APP / 'src/main/AndroidManifest.xml'
main = APP / 'src/main/java/com/muse/videoeditor/MainActivity.java'
html = APP / 'src/main/assets/www/index.html'
gradle = APP / 'build.gradle'
settings = ROOT / 'settings.gradle'

try:
    tree = ET.parse(manifest)
    ns = {'a': 'http://schemas.android.com/apk/res/android'}
    app = tree.getroot().find('application')
    activities = app.findall('activity') if app is not None else []
    launcher = any(
        any(x.attrib.get('{http://schemas.android.com/apk/res/android}name') == 'android.intent.action.MAIN'
            for x in a.findall('intent-filter/action'))
        and any(x.attrib.get('{http://schemas.android.com/apk/res/android}name') == 'android.intent.category.LAUNCHER'
                for x in a.findall('intent-filter/category'))
        for a in activities
    )
    check('Manifest XML parses', True)
    check('Launcher activity declared', launcher)
    permissions = {e.attrib.get('{http://schemas.android.com/apk/res/android}name') for e in tree.getroot().findall('uses-permission')}
    features = {e.attrib.get('{http://schemas.android.com/apk/res/android}name'): e.attrib.get('{http://schemas.android.com/apk/res/android}required', 'true') for e in tree.getroot().findall('uses-feature')}
    check('Media-library permissions declared for editor imports', all(x in permissions for x in ['android.permission.READ_MEDIA_VIDEO', 'android.permission.READ_MEDIA_AUDIO', 'android.permission.READ_MEDIA_IMAGES']))
    check('Camera hardware remains optional', features.get('android.hardware.camera') == 'false')
    check('Microphone hardware remains optional', features.get('android.hardware.microphone') == 'false')
except Exception as exc:
    check('Manifest XML parses', False, str(exc))

check('MainActivity exists', main.is_file())
legacy_main = ROOT / 'MainActivity.java'
check('Legacy MainActivity mirror matches Gradle module', legacy_main.is_file() and main.is_file() and legacy_main.read_bytes() == main.read_bytes())
check('All three editor HTML payloads exist', all(x.is_file() for x in [ROOT.parent / 'mobile-video-editor.html', ROOT / 'assets/www/index.html', html]))
check('Editor HTML exists', html.is_file() and html.stat().st_size > 100_000)

# Parse inline JavaScript in every shipped HTML copy with Node when available.
# Checking only the canonical file can miss a stale/broken packaged copy.
node = shutil.which('node')
html_copies = [ROOT.parent / 'mobile-video-editor.html', ROOT / 'assets/www/index.html', html]
if node:
    js_ok = True
    js_error = ''
    checked_scripts = 0
    with tempfile.TemporaryDirectory(prefix='cutlite-js-') as tmp:
        for copy_index, html_copy in enumerate(html_copies):
            if not html_copy.is_file():
                continue
            page = html_copy.read_text(errors='replace')
            scripts = re.findall(r'<script\b[^>]*>(.*?)</script\s*>', page, re.I | re.S)
            for index, script in enumerate(scripts):
                if not script.strip():
                    continue
                checked_scripts += 1
                js_file = Path(tmp) / f'copy-{copy_index}-inline-{index}.js'
                js_file.write_text(script)
                result = subprocess.run([node, '--check', str(js_file)], capture_output=True, text=True)
                if result.returncode:
                    js_ok = False
                    js_error = f'{html_copy}: {result.stderr.strip()[:400]}'
                    break
            if not js_ok:
                break
    check('Inline JavaScript syntax in all shipped HTML copies', js_ok and checked_scripts > 0, js_error or f'{checked_scripts} script blocks checked')
else:
    check('Node.js available for optional JavaScript syntax check', True, 'skipped: Node.js not installed')
check('Gradle app module exists', gradle.is_file() and settings.is_file())

# Ensure the canonical editor payload is identical in the legacy and Gradle layouts.
canonical_html = ROOT.parent / 'mobile-video-editor.html'
legacy_html = ROOT / 'assets' / 'www' / 'index.html'
if canonical_html.is_file() and html.is_file():
    same = canonical_html.read_bytes() == html.read_bytes()
    check('Packaged editor matches canonical editor source', same)
    check('Legacy asset copy matches canonical editor source', legacy_html.is_file() and legacy_html.read_bytes() == canonical_html.read_bytes())
else:
    check('Canonical editor source is present for parity check', canonical_html.is_file())

# Required Gradle inputs must be explicit and reproducible.
root_build = ROOT / 'build.gradle'
check('Android Gradle Plugin pinned', root_build.is_file() and 'com.android.application' in root_build.read_text(errors='replace') and '8.7.3' in root_build.read_text(errors='replace'))
check('Java 17 compile target declared', gradle.is_file() and 'JavaVersion.VERSION_17' in gradle.read_text(errors='replace'))

if main.exists():
    source = main.read_text(errors='replace')
    check('WebExtension bridge routes to current Activity after recreation', 'private static volatile MainActivity activeActivity' in source and 'MainActivity target = activeActivity' in source and 'target.handleBridgeMessage(message)' in source)
    check('Destroyed Activity releases active bridge target', 'if (activeActivity == this) activeActivity = null;' in source)
    check('Export metadata survives Activity recreation', 'private static final Map<String, JSONObject> pendingExports' in source and 'pendingExports.clear();' not in source)
    check('Native encode queue is process-wide', 'private static final Semaphore encodePermit = new Semaphore(1, true);' in source)
    mirrors = [ROOT / 'MainActivity.java', ROOT / 'MainActivity-base.java', ROOT / 'app/src/main/java/MainActivity.java']
    check('Legacy Java mirrors match Gradle source', all(p.is_file() and p.read_bytes() == main.read_bytes() for p in mirrors))
    check('FFmpeg native export integration present', 'FFmpegKit.executeAsync' in source)
    check('MP4 encoder avoids GPL-only libx264 dependency', '-c:v mpeg4' in source and 'libx264' not in source)
    check('MP4 output is accurately labeled MPEG-4 Part 2', 'MP4 (MPEG-4 Part 2)' in source)
    check('Android runtime permission callback present', 'onRequestPermissionsResult' in source)
    check('Unique staged export files', 'File.createTempFile("cutlite-"' in source)
    check('Partial MediaStore item cleanup', 'getContentResolver().delete(insertedUri' in source)
    check('Staged file cleanup after direct save', 'staged.delete();' in source)
    check('Startup failure screen can share diagnostics', 'shareDiagnosticLog()' in source and 'Intent.ACTION_SEND' in source)
    check('Activity destruction resolves pending prompts', 'pendingFilePrompt.dismiss()' in source and 'pendingMediaPermissionCallback.reject()' in source)
    check('Local server thread is interrupted on destroy', 'httpThread.interrupt()' in source)
    check('GeckoRuntime retained process-wide', 'private static volatile GeckoRuntime sharedRuntime' in source and 'GeckoRuntime.create(getApplicationContext(), settings)' in source)
    check('GeckoRuntime reused after Activity recreation', 'Reusing process-wide GeckoRuntime' in source)
    check('Diagnostic log is size-bounded', '512 * 1024' in source and 'cutlite-startup.previous.log' in source)
    check('Local server uses a stable socket reference', 'final ServerSocket server = httpServer' in source and 'server.accept()' in source)
    check('Localhost origin port is stable for persistent localStorage', 'LOCAL_SERVER_PORT = 18765' in source and 'new InetSocketAddress(InetAddress.getByName("127.0.0.1"), LOCAL_SERVER_PORT)' in source and 'new ServerSocket(0' not in source)
    check('Server bind failure stops startup instead of loading opaque resource origin', 'Your saved projects have not been deleted.' in source and 'session.loadUri("resource://android/assets/www/index.html")' not in source)
    check('FFmpeg capability follows actual process bitness', 'Process.is64Bit()' in source and 'Build.SUPPORTED_64_BIT_ABIS' in source)
    check('Missing native FFmpeg linkage falls back without app crash', 'catch (LinkageError e)' in source and 'FFmpeg native linkage failure' in source)
    check('32-bit ARM avoids unavailable FFmpeg native calls', 'supportsNativeEncoder()' in source and '!supportsNativeEncoder()' in source)
    check('WebM fallback keeps truthful file extension and MIME', 'base + ".webm"' in source and '"video/webm"' in source and '"audio/webm"' in source)
    check('MP4 fallback codec is not mislabeled as H.264', '-c:v mpeg4' in source and 'MP4 (MPEG-4 Part 2)' in source)
    check('MP3 export failure preserves WebM audio container', 'audioOnly ? "audio/webm"' in source and 'saveOriginalWebM(staged, filename' in source)

if gradle.exists():
    g = gradle.read_text(errors='replace')
    check('Minimum Android API is 26+', bool(re.search(r'minSdk\s+2[6-9]|minSdk\s+[3-9]\d', g)))
    check('ARM64 ABI included', 'arm64-v8a' in g)
    check('GeckoView dependency declared', 'geckoview' in g.lower())
    check('FFmpegKit dependency declared', 'ffmpeg-kit' in g.lower())
    check('Both common ARM ABIs included', all(x in g for x in ['arm64-v8a', 'armeabi-v7a']))

hardcoded = []
for f in [ROOT/'gradle.properties', ROOT/'build.gradle', ROOT/'settings.gradle', gradle]:
    if f.exists() and re.search(r'/home/[^\s"\']+', f.read_text(errors='replace')):
        hardcoded.append(str(f.relative_to(ROOT)))
check('No machine-specific /home paths in Gradle config', not hardcoded, ', '.join(hardcoded))

failed = 0
for label, ok, detail in checks:
    print(('PASS' if ok else 'FAIL') + '  ' + label + ((' — ' + detail) if detail else ''))
    failed += not ok
print(f'\n{len(checks)-failed}/{len(checks)} checks passed.')
if failed:
    sys.exit(1)
print('NOTE: Gradle assembleDebug and real-device tests are still required.')

#!/usr/bin/env python3
"""Syntax-check packaged bridge JS and inline editor scripts with Node.js."""
from html.parser import HTMLParser
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[2]
NODE = shutil.which('node')
if not NODE:
    print('SKIP: Node.js is not installed; JavaScript syntax validation unavailable.')
    raise SystemExit(0)

failures = 0
checked = 0

def check_source(label: str, source: str) -> None:
    global failures, checked
    checked += 1
    with tempfile.NamedTemporaryFile('w', suffix='.js', encoding='utf-8', delete=False) as tmp:
        tmp.write(source)
        path = Path(tmp.name)
    try:
        result = subprocess.run([NODE, '--check', str(path)], capture_output=True, text=True)
    finally:
        path.unlink(missing_ok=True)
    if result.returncode:
        failures += 1
        print(f'FAIL  {label}\n{result.stderr.strip()}')
    else:
        print(f'PASS  {label}')

class InlineScriptParser(HTMLParser):
    def __init__(self, label: str):
        super().__init__(convert_charrefs=False)
        self.label = label
        self.in_script = False
        self.external = False
        self.parts = []
        self.index = 0

    def handle_starttag(self, tag, attrs):
        if tag.lower() == 'script':
            self.in_script = True
            self.external = any(k.lower() == 'src' for k, _ in attrs)
            self.parts = []

    def handle_data(self, data):
        if self.in_script and not self.external:
            self.parts.append(data)

    def handle_endtag(self, tag):
        if tag.lower() == 'script' and self.in_script:
            source = ''.join(self.parts)
            if source.strip():
                self.index += 1
                check_source(f'{self.label} inline script #{self.index}', source)
            self.in_script = False
            self.external = False
            self.parts = []

for path in sorted((ROOT / 'android-app').rglob('*.js')):
    check_source(str(path.relative_to(ROOT)), path.read_text(encoding='utf-8', errors='replace'))

for path in sorted(ROOT.rglob('*.html')):
    parser = InlineScriptParser(str(path.relative_to(ROOT)))
    parser.feed(path.read_text(encoding='utf-8', errors='replace'))
    parser.close()

print(f'\n{checked - failures}/{checked} JavaScript syntax checks passed.')
if failures:
    raise SystemExit(1)

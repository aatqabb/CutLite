package com.muse.videoeditor;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.AssetManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Toast;
import android.widget.TextView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.graphics.Color;
import android.view.Gravity;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;

import org.mozilla.geckoview.GeckoResult;
import org.mozilla.geckoview.GeckoRuntime;
import org.mozilla.geckoview.GeckoRuntimeSettings;
import org.mozilla.geckoview.GeckoSession;
import org.mozilla.geckoview.GeckoView;
import org.mozilla.geckoview.WebExtension;
import org.mozilla.geckoview.WebResponse;

import com.arthenica.ffmpegkit.FFmpegKit;
import com.arthenica.ffmpegkit.FFmpegSession;
import com.arthenica.ffmpegkit.ReturnCode;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Semaphore;

/**
 * Mobile Video Editor — GeckoView (Firefox engine) build.
 *
 * The app's own rendering engine is bundled inside this APK (Mozilla
 * GeckoView 159, omni). It does NOT use the phone's System WebView.
 *
 * The editor HTML is served from an embedded localhost HTTP server
 * (http://127.0.0.1:port/) instead of resource://android/assets/ :
 * resource:// pages have an opaque (null) origin, which breaks
 * localStorage auto-save. A real http://localhost origin keeps
 * localStorage, MediaRecorder and getUserMedia working exactly like
 * in a normal browser, and localhost is a secure context.
 */
public class MainActivity extends Activity {
    private GeckoView geckoView;
    private GeckoSession session;
    // GeckoRuntime is process-scoped. Keep a strong reference and reuse it if
    // Android recreates this Activity (rotation, theme/configuration changes).
    private static volatile GeckoRuntime sharedRuntime;
    // The process-wide WebExtension can outlive an Activity recreation. Route
    // its messages to the currently visible Activity instead of retaining the
    // Activity instance that first installed the extension.
    private static volatile MainActivity activeActivity;
    private GeckoSession.PromptDelegate.FilePrompt pendingFilePrompt;
    // Keep the origin stable across Activity recreation and app restarts.
    // localStorage is scoped by scheme + host + port, so an ephemeral port
    // would make existing projects appear to disappear on every launch.
    private static final int LOCAL_SERVER_PORT = 18765;
    private ServerSocket httpServer;
    private Thread httpThread;
    private byte[] appHtml;
    private static final int FILE_REQ = 1001;
    private static final int PERM_REQ = 1002;
    private static final int MEDIA_PERM_REQ = 1003;
    // CutLite Native Bridge: the WebExtension content script reports each
    // export (filename + the format/fps/bitrate chips the user picked) just
    // before the download fires. Keyed by download filename.
    // Export metadata and the encode lock belong to the process, not an Activity.
    // A rotation/recreation must not discard a format choice or start a second
    // native encode while the first Activity's export is still completing.
    private static final Map<String, JSONObject> pendingExports = new ConcurrentHashMap<>();
    private static final Semaphore encodePermit = new Semaphore(1, true);
    private WebExtension bridgeExtension;
    // GeckoView may request Android permissions only when a feature is used.
    // Keep the callback until the user answers the system permission dialog.
    private GeckoSession.PermissionDelegate.Callback pendingAndroidPermissionCallback;
    private GeckoSession.PermissionDelegate.MediaCallback pendingMediaPermissionCallback;
    private GeckoSession.PermissionDelegate.MediaSource[] pendingMediaVideo;
    private GeckoSession.PermissionDelegate.MediaSource[] pendingMediaAudio;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        activeActivity = this;
        showStartupMessage("Starting CutLite…");
        startupLog("onCreate started; Android SDK=" + Build.VERSION.SDK_INT
                + ", ABI=" + android.os.Build.SUPPORTED_ABIS[0]);
        try {
        // Do not request media/microphone permissions before the first frame.
        // The system picker handles media selection; microphone is only needed
        // when the user starts a voiceover.
        int port = startLocalServer();
        startupLog("Local asset server port=" + port);
        if (port <= 0) {
            // Never fall back to resource:// here: it has an opaque origin and
            // would make existing localhost localStorage projects appear lost.
            // Stop visibly and preserve the diagnostic log for a retry.
            throw new java.io.IOException(
                    "CutLite could not start its local editor server on port "
                    + LOCAL_SERVER_PORT + ". Your saved projects have not been deleted. "
                    + "Close other CutLite instances and try again.");
        }
        GeckoRuntime runtime = sharedRuntime;
        if (runtime == null) {
            synchronized (MainActivity.class) {
                runtime = sharedRuntime;
                if (runtime == null) {
                    GeckoRuntimeSettings settings = new GeckoRuntimeSettings.Builder()
                            .javaScriptEnabled(true)
                            .consoleOutput(true)
                            .build();
                    startupLog("Creating process-wide GeckoRuntime");
                    runtime = GeckoRuntime.create(getApplicationContext(), settings);
                    sharedRuntime = runtime;
                    startupLog("GeckoRuntime created and retained");
                    installNativeBridge(runtime);
                }
            }
        } else {
            startupLog("Reusing process-wide GeckoRuntime");
        }
        geckoView = new GeckoView(this);
        setContentView(geckoView);
        session = new GeckoSession();
        session.setContentDelegate(new GeckoSession.ContentDelegate() {
            @Override
            public void onExternalResponse(GeckoSession session, WebResponse response) {
                saveDownload(response);
            }

            @Override
            public void onFullScreen(GeckoSession session, boolean fullScreen) {
                setFullscreen(fullScreen);
            }
        });
        session.setPromptDelegate(new GeckoSession.PromptDelegate() {
            @Override
            public GeckoResult<GeckoSession.PromptDelegate.PromptResponse> onFilePrompt(
                    GeckoSession session, GeckoSession.PromptDelegate.FilePrompt prompt) {
                pendingFilePrompt = prompt;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                startActivityForResult(Intent.createChooser(i, "Choose files"), FILE_REQ);
                return null; // handled asynchronously in onActivityResult
            }
        });
        session.setPermissionDelegate(new GeckoSession.PermissionDelegate() {
            @Override
            public void onMediaPermissionRequest(GeckoSession session, String uri,
                    GeckoSession.PermissionDelegate.MediaSource[] video,
                    GeckoSession.PermissionDelegate.MediaSource[] audio,
                    GeckoSession.PermissionDelegate.MediaCallback callback) {
                boolean needMic = audio != null && audio.length > 0;
                boolean needCam = video != null && video.length > 0;
                boolean micOk = !needMic
                        || checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                                == PackageManager.PERMISSION_GRANTED;
                boolean camOk = !needCam
                        || checkSelfPermission(Manifest.permission.CAMERA)
                                == PackageManager.PERMISSION_GRANTED;
                if (micOk && camOk) {
                    GeckoSession.PermissionDelegate.MediaSource v = needCam ? video[0] : null;
                    GeckoSession.PermissionDelegate.MediaSource a = needMic ? audio[0] : null;
                    callback.grant(v, a);
                } else if (pendingMediaPermissionCallback == null) {
                    // Ask only for the capability the page actually requested.
                    // Previously this path rejected the request without showing
                    // Android's permission dialog, making voiceover/camera fail
                    // on a fresh install unless the user visited system Settings.
                    pendingMediaPermissionCallback = callback;
                    pendingMediaVideo = video;
                    pendingMediaAudio = audio;
                    java.util.ArrayList<String> needed = new java.util.ArrayList<>();
                    if (needMic && !micOk) needed.add(Manifest.permission.RECORD_AUDIO);
                    if (needCam && !camOk) needed.add(Manifest.permission.CAMERA);
                    requestPermissions(needed.toArray(new String[0]), MEDIA_PERM_REQ);
                } else {
                    callback.reject();
                }
            }

            @Override
            public void onAndroidPermissionsRequest(GeckoSession session, String[] permissions,
                    GeckoSession.PermissionDelegate.Callback callback) {
                boolean allGranted = true;
                for (String p : permissions) {
                    if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) {
                        allGranted = false;
                        break;
                    }
                }
                if (allGranted) {
                    callback.grant();
                } else if (pendingAndroidPermissionCallback == null) {
                    pendingAndroidPermissionCallback = callback;
                    requestPermissions(permissions, PERM_REQ);
                } else {
                    // Avoid overlapping permission dialogs/callbacks.
                    callback.reject();
                }
            }
        });
        startupLog("Opening GeckoSession");
        session.open(runtime);
        geckoView.setSession(session);
        startupLog("GeckoSession attached to GeckoView");
        setFullscreen(false);
        // The server is required for the stable localhost origin used by
        // autosave. onCreate has already stopped with a diagnostic error if
        // binding failed, so never load the opaque resource:// fallback.
        session.loadUri("http://127.0.0.1:" + port + "/");
        startupLog("Gecko session opened; page load requested");
        } catch (Throwable error) {
            startupLog("FATAL startup error: " + error);
            StringWriter trace = new StringWriter();
            error.printStackTrace(new PrintWriter(trace));
            startupLog(trace.toString());
            showStartupError(error);
        }
    }

    private void showStartupMessage(String message) {
        TextView view = new TextView(this);
        view.setText(message);
        view.setTextColor(Color.WHITE);
        view.setTextSize(16);
        view.setGravity(Gravity.CENTER);
        view.setBackgroundColor(Color.rgb(18, 20, 23));
        setContentView(view);
    }

    private void showStartupError(Throwable error) {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setGravity(Gravity.CENTER);
        panel.setPadding(32, 32, 32, 32);
        panel.setBackgroundColor(Color.rgb(18, 20, 23));

        TextView view = new TextView(this);
        view.setText("CutLite could not start.\n\n"
                + error.getClass().getSimpleName() + ": "
                + (error.getMessage() == null ? "No details" : error.getMessage())
                + "\n\nYou can share the startup log with support.");
        view.setTextColor(Color.WHITE);
        view.setTextSize(15);
        view.setGravity(Gravity.CENTER);
        panel.addView(view, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        Button share = new Button(this);
        share.setText("Share diagnostic log");
        share.setOnClickListener(v -> shareDiagnosticLog());
        panel.addView(share, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT));
        setContentView(panel);
        android.util.Log.e("CutLiteStartup", "Startup failed", error);
    }

    private void shareDiagnosticLog() {
        File log = new File(getFilesDir(), "cutlite-startup.log");
        StringBuilder contents = new StringBuilder(8192);
        contents.append("CutLite startup diagnostic\nAndroid: ").append(Build.VERSION.RELEASE)
                .append(" (API ").append(Build.VERSION.SDK_INT).append(")\nDevice: ")
                .append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append("\n\n");
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                new java.io.FileInputStream(log), java.nio.charset.StandardCharsets.UTF_8))) {
            String line;
            while ((line = reader.readLine()) != null) contents.append(line).append('\n');
        } catch (Exception e) {
            contents.append("Could not read startup log: ").append(e).append('\n');
        }
        Intent share = new Intent(Intent.ACTION_SEND);
        share.setType("text/plain");
        share.putExtra(Intent.EXTRA_SUBJECT, "CutLite startup diagnostic");
        share.putExtra(Intent.EXTRA_TEXT, contents.toString());
        try {
            startActivity(Intent.createChooser(share, "Share CutLite diagnostic"));
        } catch (Exception e) {
            Toast.makeText(this, "No app available to share the log", Toast.LENGTH_LONG).show();
        }
    }

    private synchronized void startupLog(String message) {
        String line = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS",
                java.util.Locale.US).format(new Date()) + " " + message + "\n";
        android.util.Log.i("CutLiteStartup", message);
        File log = new File(getFilesDir(), "cutlite-startup.log");
        try {
            // Keep the private diagnostic file bounded on devices with little storage.
            if (log.exists() && log.length() > 512 * 1024) {
                File previous = new File(getFilesDir(), "cutlite-startup.previous.log");
                if (previous.exists()) previous.delete();
                if (!log.renameTo(previous)) log.delete();
            }
            try (FileWriter writer = new FileWriter(log, true)) {
                writer.write(line);
            }
        } catch (Exception ignored) {
            android.util.Log.w("CutLiteStartup", "Could not write startup log", ignored);
        }
    }

    // ---- CutLite Native Bridge (WebExtension -> native FFmpeg export) ----

    // Installs the built-in WebExtension that bridges the editor page to
    // this native code. The page's content script reports each export
    // (filename + format/fps/bitrate chips) and the MediaRecorder shim
    // records MP4/MP3 requests as WebM, which we then transcode with
    // FFmpegKit to real MP4 / MP3. If the extension fails to install,
    // the app still works — exports just stay as the browser's WebM.
    private void installNativeBridge(GeckoRuntime runtime) {
        try {
            runtime.getWebExtensionController()
                    .installBuiltIn("resource://android/assets/web_extensions/cutlite-bridge/")
                    .then(ext -> {
                        if (ext != null) {
                            bridgeExtension = ext;
                            ext.setMessageDelegate(new WebExtension.MessageDelegate() {
                                @Override
                                public GeckoResult<Object> onMessage(String nativeApp,
                                        Object message, WebExtension.MessageSender sender) {
                                    MainActivity target = activeActivity;
                                    if (target != null && !target.isFinishing() && !target.isDestroyed()) {
                                        target.handleBridgeMessage(message);
                                    }
                                    return GeckoResult.fromValue(null);
                                }
                            }, "com.muse.videoeditor");
                        }
                        return null;
                    });
        } catch (Exception e) {
            // Bridge unavailable; MediaRecorder export still works.
            android.util.Log.w("CutLite", "native bridge install failed: " + e);
        }
    }

    // The background script forwards the content script's export report as a
    // JSON string: {type:"export", filename, fmt, fps, br}.
    private void handleBridgeMessage(Object message) {
        try {
            String json = message == null ? null : message.toString();
            if (json == null) return;
            JSONObject o = new JSONObject(json);
            if (!"export".equals(o.optString("type"))) return;
            String filename = o.optString("filename", "");
            if (!filename.isEmpty()) pendingExports.put(filename, o);
        } catch (Exception ignored) {
        }
    }

    // ---- embedded localhost server: serves assets/www/index.html ----

    private int startLocalServer() {
        try {
            AssetManager am = getAssets();
            InputStream in = am.open("www/index.html");
            appHtml = readAll(in);
            in.close();
            httpServer = new ServerSocket();
            httpServer.setReuseAddress(true);
            httpServer.bind(new InetSocketAddress(InetAddress.getByName("127.0.0.1"), LOCAL_SERVER_PORT), 16);
            final ServerSocket server = httpServer;
            final int port = server.getLocalPort();
            startupLog("Stable local origin bound to 127.0.0.1:" + port);
            httpThread = new Thread(() -> {
                while (!server.isClosed() && !Thread.currentThread().isInterrupted()) {
                    try {
                        Socket socket = server.accept();
                        socket.setSoTimeout(10000);
                        handleHttp(socket);
                    } catch (java.net.SocketException closed) {
                        break; // expected when Activity shuts down its local server
                    } catch (Exception e) {
                        if (!server.isClosed()) startupLog("Local HTTP request failed: " + e);
                    }
                }
            }, "CutLite-LocalAssetServer");
            httpThread.setDaemon(true);
            httpThread.start();
            return port;
        } catch (Exception e) {
            startupLog("Local server failed: " + e);
            return -1;
        }
    }

    private void handleHttp(Socket s) {
        try {
            BufferedReader br = new BufferedReader(
                    new InputStreamReader(s.getInputStream(), "UTF-8"));
            OutputStream out = s.getOutputStream();
            String line = br.readLine();
            String l;
            while ((l = br.readLine()) != null && !l.isEmpty()) {
                // skip request headers
            }
            String path = "/";
            if (line != null && line.startsWith("GET ")) {
                String[] parts = line.split(" ");
                if (parts.length >= 2) path = parts[1];
            }
            if (path.equals("/") || path.equals("/index.html")) {
                String h = "HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\n"
                        + "Content-Length: " + appHtml.length + "\r\nConnection: close\r\n\r\n";
                out.write(h.getBytes("UTF-8"));
                out.write(appHtml);
            } else {
                String h = "HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\nConnection: close\r\n\r\n";
                out.write(h.getBytes("UTF-8"));
            }
            out.flush();
        } catch (Exception ignored) {
        } finally {
            try {
                s.close();
            } catch (Exception ignored) {
            }
        }
    }

    private static byte[] readAll(InputStream in) throws Exception {
        byte[] buf = new byte[8192];
        int n;
        java.io.ByteArrayOutputStream baos = new java.io.ByteArrayOutputStream();
        while ((n = in.read(buf)) != -1) baos.write(buf, 0, n);
        return baos.toByteArray();
    }

    // ---- downloads: Gecko hands the file bytes via WebResponse.body ----
    //
    // The bytes are staged in the app cache first (FFmpegKit needs a real
    // file path). If the export asked for MP4 or MP3, the staged file is
    // really WebM data (the page's MediaRecorder shim records MP4/MP3
    // requests as WebM, since Gecko cannot record those containers) — it
    // is transcoded to real MP4 / MP3 with FFmpegKit before being
    // copied to Downloads. WebM exports and other files go straight through.

    private void saveDownload(WebResponse response) {
        final String filename = filenameFrom(response);
        final String mime = headerIgnoreCase(response.headers, "content-type");
        final String mt = mime != null ? mime : "application/octet-stream";
        final InputStream body = response.body;
        try {
            response.setReadTimeoutMillis(120000);
        } catch (Exception ignored) {
        }
        new Thread(() -> {
            File cacheDir = new File(getCacheDir(), "cutlite-export");
            cacheDir.mkdirs();
            // Use a unique temporary name: two rapid exports may have the same
            // visible filename, but must never overwrite each other's staged bytes.
            File staged = null;
            try {
                if (!cacheDir.exists() && !cacheDir.mkdirs()) {
                    throw new java.io.IOException("Cannot create export cache");
                }
                staged = File.createTempFile("cutlite-", ".stage", cacheDir);
                if (body == null) {
                    staged.delete();
                    toastOnUi("Download failed: no data");
                    return;
                }
                try (InputStream input = body; OutputStream cacheOut = new FileOutputStream(staged)) {
                    byte[] buf = new byte[32 * 1024];
                    int n;
                    while ((n = input.read(buf)) != -1) cacheOut.write(buf, 0, n);
                    cacheOut.flush();
                }
                if (staged.length() <= 0) throw new java.io.IOException("Empty export data");
            } catch (Exception e) {
                if (staged != null) staged.delete();
                toastOnUi("Save failed: " + e.getMessage());
                return;
            }
            // Decide whether this export needs a native transcode.
            JSONObject opts = pendingExports.remove(filename);
            String want = wantsTranscode(staged, filename, opts);
            if (want == null) {
                // No transcode: copy the staged file to Downloads as-is.
                copyToDownloads(staged, filename, mt, null);
                staged.delete();
                return;
            }
            // The maintained FFmpeg binary currently targets 64-bit ARM and
            // x86_64. Keep the editor usable on 32-bit ARM devices by saving
            // the browser-produced WebM with an honest extension instead of
            // invoking a missing native library (which can throw LinkageError).
            if (!supportsNativeEncoder()) {
                saveOriginalWebM(staged, filename,
                        "This phone uses WebM fallback; native MP4/MP3 encoder is unavailable");
                return;
            }
            // Transcode in the background; the final file lands in Downloads.
            transcodeExport(staged, filename, want, opts);
        }).start();
    }

    // Returns "mp4" or "mp3" when the staged file must be transcoded to that
    // real format, or null when it can go to Downloads as-is. The decision
    // uses the export options the bridge reported (if any) plus the file's
    // magic bytes, so an already-real MP4/MP3 is never re-encoded.
    private String wantsTranscode(File staged, String filename, JSONObject opts) {
        if (filename == null) return null;
        String lower = filename.toLowerCase(java.util.Locale.US);
        boolean isVideo = lower.startsWith("my-video-");
        boolean isAudio = lower.equals("my-audio.mp3");
        if (!isVideo && !isAudio) return null;
        // What the user asked for: the bridge's fmt chip, else the extension.
        String fmt = opts != null ? opts.optString("fmt", "") : "";
        if (fmt.isEmpty()) {
            if (lower.endsWith(".mp4")) fmt = "mp4";
            else if (lower.endsWith(".mp3")) fmt = "mp3";
            else fmt = "webm";
        }
        if ("mp4".equals(fmt) && isVideo) {
            return isWebM(staged) ? "mp4" : null;
        }
        if ("mp3".equals(fmt) && isAudio) {
            return isWebM(staged) ? "mp3" : null;
        }
        return null;
    }


    private boolean supportsNativeEncoder() {
        // Check the ABI of this app process, not merely the device's supported
        // ABIs. A 64-bit-capable phone can still run a 32-bit APK process, for
        // which the 64-bit-only FFmpeg native library cannot be loaded.
        if (Build.VERSION.SDK_INT >= 23 && !android.os.Process.is64Bit()) return false;
        String[] processAbis = Build.SUPPORTED_64_BIT_ABIS;
        for (String abi : processAbis) {
            if ("arm64-v8a".equals(abi) || "x86_64".equals(abi)) return true;
        }
        return false;
    }

    // Preserve the actual container when native transcoding is unavailable.
    // Never leave WebM bytes under an .mp4/.mp3 filename.
    private void saveOriginalWebM(File staged, String requestedName, String note) {
        String base = requestedName == null ? "cutlite-export" : requestedName;
        int dot = base.lastIndexOf('.');
        if (dot > 0) base = base.substring(0, dot);
        boolean audioOnly = requestedName != null
                && requestedName.toLowerCase(java.util.Locale.US).endsWith(".mp3");
        String actualName = base + ".webm";
        copyToDownloads(staged, actualName, audioOnly ? "audio/webm" : "video/webm", note);
        staged.delete();
    }

    // True when the file starts with the EBML header (WebM / Matroska).
    private static boolean isWebM(File f) {
        try {
            java.io.FileInputStream in = new java.io.FileInputStream(f);
            byte[] h = new byte[4];
            int n = in.read(h);
            in.close();
            return n == 4 && h[0] == (byte) 0x1A && h[1] == (byte) 0x45
                    && h[2] == (byte) 0xDF && h[3] == (byte) 0xA3;
        } catch (Exception e) {
            return false;
        }
    }

    // Pick a conservative CPU budget from Android's memory class and core count.
    // The goal is to keep the editor responsive and reduce thermal pressure on
    // entry-level phones; high-core phones still get parallel encoding, but we
    // never let native encoding occupy every reported CPU core.
    private int chooseEncodeThreads() {
        int cores = Math.max(1, Runtime.getRuntime().availableProcessors());
        int memoryClass = 128;
        try {
            ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
            if (am != null) memoryClass = am.getMemoryClass();
        } catch (Exception ignored) { }
        if (memoryClass <= 192 || cores <= 4) return 1;
        if (memoryClass <= 320 || cores <= 6) return 2;
        return Math.min(3, cores - 1);
    }

    // Transcodes the staged export with FFmpegKit, then copies the result to
    // Downloads. Runs off the UI thread; FFmpegKit itself is async.
    private void transcodeExport(File staged, String filename, String want, JSONObject opts) {
        int quality = parseQuality(filename);          // 720 / 1080 / 2160
        int fps = parseFps(filename, opts);            // e.g. 30
        String br = opts != null ? opts.optString("br", "med") : "med";
        if (br == null || br.isEmpty()) br = "med";
        String vbit = videoBitrate(quality, br);      // e.g. "6M"
        String abit = audioBitrate(br);               // e.g. "128k"
        File out = new File(staged.getParentFile(), "ff-" + filename);
        String cmd;
        String outMime;
        // Mobile-first encode settings: veryfast avoids the long CPU-bound
        // medium preset on mid-range phones; yuv420p is accepted by virtually
        // all Android players. Keep threads bounded to avoid overheating and
        // starving the editor UI on phones with many big.LITTLE cores.
        int encodeThreads = chooseEncodeThreads();
        if ("mp4".equals(want)) {
            cmd = "-y -i \"" + staged.getAbsolutePath() + "\""
                    + " -c:v mpeg4 -threads " + encodeThreads
                    + " -pix_fmt yuv420p -b:v " + vbit
                    + " -maxrate " + vbit + " -bufsize " + vbit
                    + " -r " + fps
                    + " -c:a aac -b:a " + abit
                    + " -movflags +faststart \"" + out.getAbsolutePath() + "\"";
            outMime = "video/mp4";
        } else {
            cmd = "-y -i \"" + staged.getAbsolutePath() + "\""
                    + " -vn -threads 1 -c:a libmp3lame -b:a " + abit
                    + " \"" + out.getAbsolutePath() + "\"";
            outMime = "audio/mpeg";
        }
        boolean permitHeld = false;
        try {
            // Queue native encodes instead of letting rapid export taps launch
            // multiple FFmpeg jobs at once. Keep the wait off the UI thread.
            encodePermit.acquire();
            permitHeld = true;
            FFmpegKit.executeAsync(cmd, session -> {
                try {
                    ReturnCode rc = session.getReturnCode();
                    if (rc != null && ReturnCode.isSuccess(rc) && out.exists() && out.length() > 0) {
                        copyToDownloads(out, filename, outMime,
                                "mp4".equals(want) ? "MP4 (MPEG-4 Part 2)" : "MP3");
                    } else {
                        // Transcode failed (e.g. no native ffmpeg lib on this
                        // device): fall back to the original file as-is.
                        saveOriginalWebM(staged, filename,
                                "FFmpeg transcode failed; original WebM saved");
                    }
                } catch (Exception e) {
                    saveOriginalWebM(staged, filename, "Transcode error; original WebM saved");
                } finally {
                    staged.delete();
                    out.delete();
                    encodePermit.release();
                }
            });
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            if (permitHeld) encodePermit.release();
            saveOriginalWebM(staged, filename, "Export queue interrupted; original WebM saved");
        } catch (LinkageError e) {
            // Missing/mismatched JNI libraries are linkage failures, not
            // Exceptions. Catch them explicitly so an export cannot crash the
            // entire editor process on an unsupported ABI/device image.
            if (permitHeld) encodePermit.release();
            startupLog("FFmpeg native linkage failure: " + e.getClass().getSimpleName()
                    + ": " + e.getMessage());
            saveOriginalWebM(staged, filename, "Native encoder unavailable; original WebM saved");
        } catch (Exception e) {
            if (permitHeld) encodePermit.release();
            startupLog("FFmpeg start failed: " + e.getClass().getSimpleName()
                    + ": " + e.getMessage());
            saveOriginalWebM(staged, filename, "Native encoder unavailable; original WebM saved");
        }
    }

    private void copyToDownloads(File src, String filename, String mime, String note) {
        Uri insertedUri = null;
        try {
            if (src == null || !src.isFile() || src.length() <= 0) {
                toastOnUi("Save failed: export file is empty");
                return;
            }
            String safeName = safeDownloadName(filename);
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                v.put(MediaStore.Downloads.MIME_TYPE, mime);
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                v.put(MediaStore.MediaColumns.IS_PENDING, 1);
                insertedUri = getContentResolver().insert(
                        MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (insertedUri == null) throw new java.io.IOException("Downloads storage is unavailable");
                try (OutputStream out = getContentResolver().openOutputStream(insertedUri, "w")) {
                    if (out == null) throw new java.io.IOException("Could not open Downloads file");
                    copyFile(src, out);
                }
                ContentValues ready = new ContentValues();
                ready.put(MediaStore.MediaColumns.IS_PENDING, 0);
                getContentResolver().update(insertedUri, ready, null, null);
            } else {
                File dir = Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_DOWNLOADS);
                if (!dir.exists() && !dir.mkdirs()) throw new java.io.IOException("Cannot create Downloads folder");
                File destination = new File(dir, safeName);
                try (OutputStream out = new FileOutputStream(destination)) {
                    copyFile(src, out);
                }
            }
            toastOnUi("Saved to Downloads: " + safeName
                    + (note != null ? " (" + note + ")" : ""));
        } catch (Exception e) {
            // Do not leave a broken/half-written item visible in Downloads.
            if (insertedUri != null) {
                try { getContentResolver().delete(insertedUri, null, null); }
                catch (Exception ignored) { }
            }
            toastOnUi("Save failed: " + e.getMessage());
        }
    }

    private static void copyFile(File src, OutputStream out) throws Exception {
        try (java.io.FileInputStream in = new java.io.FileInputStream(src)) {
            byte[] buf = new byte[32 * 1024];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            out.flush();
        }
    }

    // ---- export option parsing (same numbers as the app's expBitrates()) ----

    private static int parseQuality(String filename) {
        // my-video-720p-30fps.mp4 / my-video-1080p-60fps.webm
        try {
            int p = filename.indexOf('p', filename.indexOf('-') + 1);
            int d = filename.lastIndexOf('-', p);
            return Integer.parseInt(filename.substring(d + 1, p));
        } catch (Exception e) {
            return 720;
        }
    }

    private static int parseFps(String filename, JSONObject opts) {
        if (opts != null) {
            try {
                int f = Integer.parseInt(opts.optString("fps", ""));
                if (f > 0) return f;
            } catch (Exception ignored) {
            }
        }
        try {
            int i = filename.indexOf("fps");
            int d = filename.lastIndexOf('-', i);
            return Integer.parseInt(filename.substring(d + 1, i));
        } catch (Exception e) {
            return 30;
        }
    }

    private static String videoBitrate(int quality, String br) {
        // app: 720p low 3M / med 6M / high 10M; 1080p 6M / 12M / 20M;
        // 2160p 14M / 28M / 45M.
        if (quality >= 2160) return "low".equals(br) ? "14M" : "high".equals(br) ? "45M" : "28M";
        if (quality >= 1080) return "low".equals(br) ? "6M" : "high".equals(br) ? "20M" : "12M";
        return "low".equals(br) ? "3M" : "high".equals(br) ? "10M" : "6M";
    }

    private static String audioBitrate(String br) {
        return "low".equals(br) ? "96k" : "high".equals(br) ? "192k" : "128k";
    }

    private String filenameFrom(WebResponse r) {
        String cd = headerIgnoreCase(r.headers, "content-disposition");
        if (cd != null) {
            int i = cd.indexOf("filename=");
            if (i >= 0) {
                String f = cd.substring(i + 9).trim();
                if (f.startsWith("\"")) {
                    int j = f.indexOf('"', 1);
                    if (j > 0) f = f.substring(1, j);
                } else {
                    int j = f.indexOf(';');
                    if (j >= 0) f = f.substring(0, j);
                    f = f.trim();
                }
                if (!f.isEmpty()) return safeDownloadName(f);
            }
        }
        if (r.uri != null) {
            int s = r.uri.lastIndexOf('/');
            if (s >= 0 && s < r.uri.length() - 1) {
                String last = r.uri.substring(s + 1);
                int q = last.indexOf('?');
                if (q >= 0) last = last.substring(0, q);
                if (!last.isEmpty() && last.contains(".")) return safeDownloadName(last);
            }
        }
        String ct = headerIgnoreCase(r.headers, "content-type");
        if (ct != null) {
            String c = ct.toLowerCase(java.util.Locale.US);
            if (c.contains("audio/mpeg") || c.contains("audio/mp3")) return "my-audio.mp3";
            if (c.contains("xml")) return "CutLite-Premiere.xml";
            if (c.contains("mp4")) return "my-video.mp4";
            if (c.contains("webm")) return "my-video.webm";
        }
        return "my-video.webm";
    }

    // Never let a remote/content-provided filename escape the app cache or
    // create confusing path-like names in Downloads.
    private static String safeDownloadName(String raw) {
        String name = raw == null ? "" : raw.replace('\\', '/');
        int slash = name.lastIndexOf('/');
        if (slash >= 0) name = name.substring(slash + 1);
        name = name.replaceAll("[^A-Za-z0-9._ -]", "_").trim();
        while (name.startsWith(".")) name = name.substring(1);
        if (name.isEmpty()) name = "CutLite-export.webm";
        if (name.length() > 120) {
            int dot = name.lastIndexOf('.');
            String ext = dot > 0 ? name.substring(dot) : "";
            name = name.substring(0, Math.min(110, name.length() - ext.length())) + ext;
        }
        return name;
    }

    private static String headerIgnoreCase(java.util.Map<String, String> headers, String name) {
        if (headers == null) return null;
        for (java.util.Map.Entry<String, String> e : headers.entrySet()) {
            if (e.getKey() != null && e.getKey().equalsIgnoreCase(name)) return e.getValue();
        }
        return null;
    }

    private void toastOnUi(String msg) {
        runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show());
    }

    private void setFullscreen(boolean fullScreen) {
        int flags = View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION;
        if (fullScreen) {
            flags |= View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY;
        }
        getWindow().getDecorView().setSystemUiVisibility(flags);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
            int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MEDIA_PERM_REQ) {
            GeckoSession.PermissionDelegate.MediaCallback callback = pendingMediaPermissionCallback;
            GeckoSession.PermissionDelegate.MediaSource[] video = pendingMediaVideo;
            GeckoSession.PermissionDelegate.MediaSource[] audio = pendingMediaAudio;
            pendingMediaPermissionCallback = null;
            pendingMediaVideo = null;
            pendingMediaAudio = null;
            if (callback == null) return;
            boolean granted = grantResults != null && grantResults.length > 0;
            if (grantResults != null) {
                for (int result : grantResults) {
                    if (result != PackageManager.PERMISSION_GRANTED) {
                        granted = false;
                        break;
                    }
                }
            }
            boolean micOk = audio == null || audio.length == 0
                    || checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
            boolean camOk = video == null || video.length == 0
                    || checkSelfPermission(Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED;
            if (granted && micOk && camOk) {
                callback.grant(video != null && video.length > 0 ? video[0] : null,
                        audio != null && audio.length > 0 ? audio[0] : null);
            } else {
                callback.reject();
                toastOnUi("Permission denied. Allow microphone or camera access to use this feature.");
            }
            return;
        }
        if (requestCode != PERM_REQ) return;
        GeckoSession.PermissionDelegate.Callback callback = pendingAndroidPermissionCallback;
        pendingAndroidPermissionCallback = null;
        if (callback == null) return;
        boolean granted = grantResults != null && grantResults.length > 0;
        if (grantResults != null) {
            for (int result : grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    granted = false;
                    break;
                }
            }
        }
        if (granted) callback.grant(); else callback.reject();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == FILE_REQ) {
            GeckoSession.PromptDelegate.FilePrompt prompt = pendingFilePrompt;
            pendingFilePrompt = null;
            if (prompt != null) {
                if (res == RESULT_OK && data != null) {
                    Uri[] result = null;
                    if (data.getClipData() != null) {
                        int n = data.getClipData().getItemCount();
                        result = new Uri[n];
                        for (int k = 0; k < n; k++) {
                            result[k] = data.getClipData().getItemAt(k).getUri();
                        }
                    } else if (data.getData() != null) {
                        result = new Uri[]{data.getData()};
                    }
                    if (result != null) prompt.confirm(this, result);
                    else prompt.dismiss();
                } else {
                    prompt.dismiss();
                }
            }
        } else {
            super.onActivityResult(req, res, data);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (session != null) session.setActive(false);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (session != null) session.setActive(true);
    }

    @Override
    protected void onDestroy() {
        // Resolve outstanding Gecko prompts before the Activity disappears so
        // Gecko does not retain callbacks that point at a dead Activity.
        if (pendingFilePrompt != null) {
            try { pendingFilePrompt.dismiss(); } catch (Exception ignored) { }
            pendingFilePrompt = null;
        }
        if (pendingAndroidPermissionCallback != null) {
            try { pendingAndroidPermissionCallback.reject(); } catch (Exception ignored) { }
            pendingAndroidPermissionCallback = null;
        }
        if (pendingMediaPermissionCallback != null) {
            try { pendingMediaPermissionCallback.reject(); } catch (Exception ignored) { }
            pendingMediaPermissionCallback = null;
            pendingMediaVideo = null;
            pendingMediaAudio = null;
        }
        // Do not clear process-wide export metadata here: a download/encode may
        // still be in flight while Android recreates this Activity.
        if (activeActivity == this) activeActivity = null;
        try {
            if (httpServer != null) httpServer.close(); // unblocks accept()
        } catch (Exception ignored) { }
        if (httpThread != null) httpThread.interrupt();
        if (session != null) {
            try { session.setActive(false); } catch (Exception ignored) { }
            try { session.close(); } catch (Exception ignored) { }
            session = null;
        }
        // GeckoRuntime is process-wide and intentionally left alive; destroying
        // it here can break a replacement Activity after configuration change.
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
    }
}

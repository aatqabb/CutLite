// CutLite Native Bridge — background script.
// Relays messages between the page (content script) and the native app.
// The native side registers a MessageDelegate for the app id below and
// receives these messages in MainActivity. Messages are sent as a JSON
// string so the Java side always receives a plain String to parse.
var NATIVE_APP = "com.muse.videoeditor";

browser.runtime.onMessage.addListener(function (msg, sender) {
  // Forward to native; the returned promise resolves with the native reply.
  return browser.runtime.sendNativeMessage(NATIVE_APP, JSON.stringify(msg));
});

// CutLite Native Bridge — content script (runs at document_start).
// It injects the page-world bridge (a <script> tag) because content scripts
// run in an isolated JS world and cannot patch the page's own objects
// (window.MediaRecorder, HTMLAnchorElement.prototype) directly.
// The injected script talks back via window.postMessage; this script relays
// those messages to the background script, which forwards them to native.
(function () {
  var PAGE_SCRIPT = "(function(){"
    + "try{"
    // ---- 1. Make the app believe MP4/MP3 recording is supported ----
    + "var NativeMR = window.MediaRecorder;"
    + "if(!NativeMR || !window.__cutliteBridge) {"
    + "window.__cutliteBridge = true;"
    + "var isMp4 = function(m){ return typeof m === 'string' && m.indexOf('video/mp4') === 0; };"
    + "var isMp3 = function(m){ return m === 'audio/mpeg' || m === 'audio/mp3'; };"
    + "var pickWebmVideo = function(){"
    + "  var cands = ['video/webm;codecs=vp9,opus','video/webm;codecs=vp8,opus','video/webm;codecs=vp9','video/webm;codecs=vp8','video/webm'];"
    + "  for (var i=0;i<cands.length;i++){ try{ if(NativeMR.isTypeSupported(cands[i])) return cands[i]; }catch(e){} }"
    + "  return 'video/webm';"
    + "};"
    + "var pickWebmAudio = function(){"
    + "  var cands = ['audio/webm;codecs=opus','audio/webm'];"
    + "  for (var i=0;i<cands.length;i++){ try{ if(NativeMR.isTypeSupported(cands[i])) return cands[i]; }catch(e){} }"
    + "  return 'audio/webm';"
    + "};"
    // Wrap the constructor: record mp4/mp3 requests as WebM (which Gecko
    // really supports); the native side transcodes the file to real MP4/MP3.
    + "var CutLiteMR = function(stream, options){"
    + "  var opts = options || {};"
    + "  if (opts.mimeType && isMp4(opts.mimeType)) { opts = Object.assign({}, opts, {mimeType: pickWebmVideo()}); }"
    + "  else if (opts.mimeType && isMp3(opts.mimeType)) { opts = Object.assign({}, opts, {mimeType: pickWebmAudio()}); }"
    + "  return new NativeMR(stream, opts);"
    + "};"
    + "CutLiteMR.prototype = NativeMR.prototype;"
    + "CutLiteMR.isTypeSupported = function(m){"
    + "  try{ if (isMp4(m) || isMp3(m)) return true; }catch(e){}"
    + "  try{ return NativeMR.isTypeSupported(m); }catch(e){ return false; }"
    + "};"
    + "window.MediaRecorder = CutLiteMR;"
    // ---- 2. Detect export downloads and report the chosen options ----
    + "var origClick = HTMLAnchorElement.prototype.click;"
    + "HTMLAnchorElement.prototype.click = function(){"
    + "  try{"
    + "    var dl = this.download || '';"
    + "    if (dl.indexOf('my-video-') === 0 || dl.indexOf('my-audio') === 0) {"
    + "      var sel = function(row){ var el = document.querySelector(row + ' .chip.sel'); return el ? (el.dataset.fmt || el.dataset.fps || el.dataset.br || '') : ''; };"
    + "      window.postMessage({ __cutlite: 'export', filename: dl, fmt: sel('#fmtRow'), fps: sel('#fpsRow'), br: sel('#brRow') }, '*');"
    + "    }"
    + "  }catch(e){}"
    + "  return origClick.call(this);"
    + "};"
    // ---- 3. Minimal native handle for the page ----
    + "window.CutLiteNative = { available: true, engine: 'ffmpeg-kit' };"
    + "}"
    + "}catch(e){}"
    + "})();";

  function inject() {
    var s = document.createElement("script");
    s.textContent = PAGE_SCRIPT;
    (document.documentElement || document.head || document.body).appendChild(s);
    s.remove();
  }
  if (document.documentElement) { inject(); }
  else { document.addEventListener("DOMContentLoaded", inject); }

  // Relay page messages to the background script (which forwards to native).
  window.addEventListener("message", function (ev) {
    try {
      var d = ev.data;
      if (d && d.__cutlite === "export") {
        browser.runtime.sendMessage({
          type: "export",
          filename: d.filename,
          fmt: d.fmt,
          fps: d.fps,
          br: d.br
        });
      }
    } catch (e) {}
  });
})();

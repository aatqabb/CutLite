# Stable Local Origin Fix

The local HTTP asset server previously bound to port `0`, which asks Android for an arbitrary free port. Because browser `localStorage` is scoped by scheme, host, and port, the editor received a different origin on a later launch. Existing project data could then appear to be missing.

The server now binds to loopback `127.0.0.1:18765` with address reuse enabled. All maintained Java source mirrors are synchronized, and preflight verifies that the fixed port is used rather than an ephemeral port.

Validation: `scripts/preflight.py` — 47/47; `scripts/validate_javascript.py` — 7/7. These are source checks only. Gradle compilation and physical-device verification remain required.

# Export lifecycle retention fix

The export metadata map and native encode semaphore are now process-scoped rather than Activity-scoped.

Why this matters:
- Android may recreate an Activity during rotation or configuration changes while a WebResponse download is still being staged.
- Clearing the pending export map in `onDestroy()` could discard the user's selected MP4/MP3 format before the download worker consumes it.
- An Activity-owned semaphore could allow a second encode to start after recreation while the first Activity's asynchronous FFmpeg callback was still running.

Changes:
- `pendingExports` is a static process-wide concurrent map.
- `encodePermit` is a static process-wide fair semaphore.
- `onDestroy()` no longer clears in-flight export metadata.
- All Java source mirrors are synchronized with the Gradle module source.

Validation: offline preflight and JavaScript syntax checks only. Gradle compilation and physical-device tests remain required.

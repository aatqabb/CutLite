# Native ABI fallback update

The maintained FFmpegKit 8.1.9 artifact documents 64-bit ARM and x86_64 native binaries, not 32-bit ARM (`armeabi-v7a`). The editor can still run on a 32-bit Android device when its GeckoView build supports that ABI, but native MP4/MP3 conversion is not available there.

CutLite now checks the device ABI before invoking FFmpegKit. On unsupported ABIs it saves the actual browser-produced WebM container with a `.webm` extension and the matching `video/webm` or `audio/webm` MIME type. It does not attempt to load a missing native library, and it does not mislabel WebM bytes as MP4/MP3. Native transcode failures use the same truthful fallback.

This is a compatibility fallback, not MP4/MP3 support on 32-bit devices. Full native encoder support there would require a separately built and maintained 32-bit FFmpeg binary.

Validation: offline source preflight and inline JavaScript syntax check pass. Gradle compilation and physical-device tests remain outstanding.
